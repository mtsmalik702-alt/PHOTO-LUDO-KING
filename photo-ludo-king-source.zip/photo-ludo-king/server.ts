import express from 'express';
import fs from 'fs/promises';
import http from 'http';
import JSZip from 'jszip';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import {
  applyDiceRoll,
  applyTokenMove,
  advanceAfterNoMoves,
  createInitialGameState,
  resetMatchKeepProfiles,
  updatePlayerProfile,
} from './src/shared/ludoEngine.ts';
import type { LudoGameState, PlayerId } from './src/shared/ludoEngine.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface RoomSeat {
  sessionId: string;
  ws: WebSocket | null;
}

interface RoomRecord {
  code: string;
  state: LudoGameState;
  seats: Partial<Record<PlayerId, RoomSeat>>;
  noMovesTimer: ReturnType<typeof setTimeout> | null;
  updatedAt: number;
}

const rooms = new Map<string, RoomRecord>();
const ROOM_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

function generateRoomCode(): string {
  for (let attempt = 0; attempt < 50; attempt++) {
    let code = '';
    for (let i = 0; i < 5; i++) {
      code += ROOM_CHARS[Math.floor(Math.random() * ROOM_CHARS.length)];
    }
    if (!rooms.has(code)) return code;
  }
  return Math.random().toString(36).substring(2, 7).toUpperCase();
}

function sendJson(ws: WebSocket | null | undefined, payload: unknown): void {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function broadcastRoomState(room: RoomRecord): void {
  room.updatedAt = Date.now();
  for (const playerId of ['P1', 'P2'] as PlayerId[]) {
    const seat = room.seats[playerId];
    sendJson(seat?.ws, {
      type: 'room:state',
      seat: playerId,
      roomCode: room.code,
      state: room.state,
    });
  }
}

function scheduleNoMovesAdvance(room: RoomRecord): void {
  if (room.noMovesTimer) {
    clearTimeout(room.noMovesTimer);
    room.noMovesTimer = null;
  }
  if (room.state.phase === 'NO_MOVES') {
    room.noMovesTimer = setTimeout(() => {
      room.noMovesTimer = null;
      room.state = advanceAfterNoMoves(room.state);
      broadcastRoomState(room);
    }, 1150);
  }
}

// Periodic cleanup of abandoned rooms older than 4 hours
setInterval(() => {
  const cutoff = Date.now() - 4 * 60 * 60 * 1000;
  for (const [code, room] of rooms.entries()) {
    if (room.updatedAt < cutoff) {
      if (room.noMovesTimer) clearTimeout(room.noMovesTimer);
      rooms.delete(code);
    }
  }
}, 15 * 60 * 1000);

async function startServer() {
  const app = express();
  const server = http.createServer(app);

  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, activeRooms: rooms.size });
  });

  const EXCLUDED_DIRS = new Set(['node_modules', 'dist', '.git', '.aistudio']);
  const EXCLUDED_FILES = new Set(['.env', 'bun.lock', 'package-lock.json']);

  async function addDirectoryToZip(
    zipFolder: JSZip,
    currentDir: string
  ): Promise<void> {
    const entries = await fs.readdir(currentDir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.isDirectory()) {
        if (EXCLUDED_DIRS.has(entry.name)) continue;
        const subZip = zipFolder.folder(entry.name);
        if (subZip) {
          await addDirectoryToZip(subZip, path.join(currentDir, entry.name));
        }
      } else if (entry.isFile()) {
        if (EXCLUDED_FILES.has(entry.name) || entry.name.endsWith('.zip')) continue;
        const fileData = await fs.readFile(path.join(currentDir, entry.name));
        zipFolder.file(entry.name, fileData);
      }
    }
  }

  const handleDownloadSourceZip: express.RequestHandler = async (_req, res) => {
    try {
      const zip = new JSZip();
      const rootFolder = zip.folder('photo-ludo-king') || zip;
      await addDirectoryToZip(rootFolder, __dirname);

      const zipBuffer = await zip.generateAsync({
        type: 'nodebuffer',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      });

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="photo-ludo-king-source.zip"'
      );
      res.setHeader('Content-Length', String(zipBuffer.length));
      res.setHeader('Cache-Control', 'no-store');
      res.status(200).send(zipBuffer);
    } catch (err) {
      console.error('Failed to generate source ZIP:', err);
      res.status(500).json({ error: 'Failed to generate ZIP backup.' });
    }
  };

  app.get('/api/download-source-zip', handleDownloadSourceZip);
  app.get('/photo-ludo-king-source.zip', handleDownloadSourceZip);

  app.get('/api/rooms/:code', (req, res) => {
    const code = (req.params.code || '').trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) {
      res.status(404).json({ exists: false, message: 'Room code not found.' });
      return;
    }
    const p1Taken = Boolean(room.seats.P1);
    const p2Taken = Boolean(room.seats.P2);
    res.json({
      exists: true,
      code: room.code,
      isFull: p1Taken && p2Taken,
      hostName: room.state.players.P1.name,
    });
  });

  const wss = new WebSocketServer({ noServer: true, maxPayload: 2 * 1024 * 1024 });

  server.on('upgrade', (request, socket, head) => {
    const reqUrl = request.url || '';
    if (reqUrl.startsWith('/ws')) {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } else if (process.env.DISABLE_HMR === 'true' || process.env.NODE_ENV === 'production') {
      socket.destroy();
    }
  });

  wss.on('connection', (ws) => {
    let joinedRoomCode: string | null = null;
    let assignedSeat: PlayerId | null = null;

    ws.on('message', (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        sendJson(ws, { type: 'room:error', message: 'Invalid message format.' });
        return;
      }

      const type = msg.type;
      const sessionId = typeof msg.sessionId === 'string' ? msg.sessionId : '';

      if (type === 'room:create') {
        const name = typeof msg.name === 'string' ? msg.name.trim().slice(0, 20) : 'Player 1';
        const photo = typeof msg.photo === 'string' ? msg.photo : null;
        const code = generateRoomCode();
        const initialState = createInitialGameState('ONLINE', code, {
          name: name || 'Player 1',
          photo,
          connected: true,
        });

        const room: RoomRecord = {
          code,
          state: initialState,
          seats: {
            P1: { sessionId, ws },
          },
          noMovesTimer: null,
          updatedAt: Date.now(),
        };
        rooms.set(code, room);
        joinedRoomCode = code;
        assignedSeat = 'P1';
        broadcastRoomState(room);
        return;
      }

      if (type === 'room:join') {
        const code = typeof msg.roomCode === 'string' ? msg.roomCode.trim().toUpperCase() : '';
        const name = typeof msg.name === 'string' ? msg.name.trim().slice(0, 20) : '';
        const photo = typeof msg.photo === 'string' ? msg.photo : undefined;

        const room = rooms.get(code);
        if (!room) {
          sendJson(ws, {
            type: 'room:error',
            message: `Room "${code}" was not found. Double-check the 5-character code!`,
          });
          return;
        }

        // Check if reconnecting to an existing seat via sessionId
        let seatToAssign: PlayerId | null = null;
        if (sessionId && room.seats.P1?.sessionId === sessionId) {
          seatToAssign = 'P1';
        } else if (sessionId && room.seats.P2?.sessionId === sessionId) {
          seatToAssign = 'P2';
        } else if (!room.seats.P1) {
          seatToAssign = 'P1';
        } else if (!room.seats.P2) {
          seatToAssign = 'P2';
        } else if (!room.state.players.P2.connected) {
          // Allow reclaiming disconnected P2 slot if friend dropped permanently
          seatToAssign = 'P2';
        }

        if (!seatToAssign) {
          sendJson(ws, {
            type: 'room:error',
            message: `Room "${code}" already has 2 active players.`,
          });
          return;
        }

        room.seats[seatToAssign] = { sessionId, ws };
        joinedRoomCode = code;
        assignedSeat = seatToAssign;

        room.state = {
          ...room.state,
          players: {
            ...room.state.players,
            [seatToAssign]: {
              ...room.state.players[seatToAssign],
              connected: true,
              name:
                name ||
                (seatToAssign === 'P2' &&
                room.state.players.P2.name === 'Waiting for Friend'
                  ? 'Player 2'
                  : room.state.players[seatToAssign].name),
              photo: photo !== undefined ? photo : room.state.players[seatToAssign].photo,
            },
          },
        };

        // Transition from WAITING_FOR_PLAYERS -> ROLL once both seats have joined
        if (
          room.state.phase === 'WAITING_FOR_PLAYERS' &&
          room.seats.P1 &&
          room.seats.P2
        ) {
          room.state = {
            ...room.state,
            phase: 'ROLL',
            turn: 'P1',
            statusMessage: `${room.state.players.P1.name}'s turn — tap Roll Dice!`,
          };
        }

        broadcastRoomState(room);
        return;
      }

      if (!joinedRoomCode || !assignedSeat) {
        return;
      }

      const room = rooms.get(joinedRoomCode);
      if (!room) return;

      if (type === 'player:updateProfile') {
        const name = typeof msg.name === 'string' ? msg.name : undefined;
        const photo =
          msg.photo === null || typeof msg.photo === 'string' ? msg.photo : undefined;
        room.state = updatePlayerProfile(room.state, assignedSeat, { name, photo });
        broadcastRoomState(room);
        return;
      }

      if (type === 'game:roll') {
        const prevRollCount = room.state.rollCount;
        room.state = applyDiceRoll(room.state, assignedSeat);
        if (room.state.rollCount !== prevRollCount) {
          broadcastRoomState(room);
          scheduleNoMovesAdvance(room);
        }
        return;
      }

      if (type === 'game:move') {
        const tokenId = typeof msg.tokenId === 'number' ? msg.tokenId : -1;
        const prevMoveId = room.state.lastMove?.moveId ?? 0;
        room.state = applyTokenMove(room.state, assignedSeat, tokenId);
        if ((room.state.lastMove?.moveId ?? 0) !== prevMoveId) {
          broadcastRoomState(room);
        }
        return;
      }

      if (type === 'game:rematch') {
        room.state = resetMatchKeepProfiles(room.state);
        broadcastRoomState(room);
        return;
      }
    });

    ws.on('close', () => {
      if (!joinedRoomCode || !assignedSeat) return;
      const room = rooms.get(joinedRoomCode);
      if (!room) return;
      const currentSeat = room.seats[assignedSeat];
      if (currentSeat && currentSeat.ws === ws) {
        currentSeat.ws = null;
        room.state = {
          ...room.state,
          players: {
            ...room.state.players,
            [assignedSeat]: {
              ...room.state.players[assignedSeat],
              connected: false,
            },
          },
        };
        broadcastRoomState(room);
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    let viteMiddleware: express.RequestHandler | null = null;
    const viteReady = (async () => {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: {
          middlewareMode: true,
          hmr: process.env.DISABLE_HMR === 'true' ? false : { server },
        },
        appType: 'spa',
      });
      viteMiddleware = vite.middlewares;
    })();

    app.use(async (req, res, next) => {
      try {
        if (!viteMiddleware) {
          await viteReady;
        }
        viteMiddleware!(req, res, next);
      } catch (err) {
        next(err);
      }
    });
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = 3000;
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Photo Ludo King server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
