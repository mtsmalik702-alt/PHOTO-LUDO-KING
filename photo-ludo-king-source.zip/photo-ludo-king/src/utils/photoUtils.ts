/**
 * Utilities for loading, framing, cropping, and compressing photos uploaded from
 * Android/iOS phone galleries so they look sharp on all 4 Ludo tokens and sync
 * instantly over WebSockets.
 */

export interface CropTransform {
  zoom: number; // 1.0 to 3.0
  offsetX: number; // -1.0 to 1.0 (fraction of extrapan)
  offsetY: number; // -1.0 to 1.0
}

export function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Could not read the selected photo.'));
    img.src = src;
  });
}

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Unsupported photo format.'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to open photo from gallery.'));
    reader.readAsDataURL(file);
  });
}

/**
 * Renders a crisp 256x256 square avatar JPEG (~15-30 KB) applying user zoom and pan.
 */
export async function renderSquareTokenPhoto(
  imageSrc: string,
  transform: CropTransform = { zoom: 1, offsetX: 0, offsetY: 0 },
  outputSize = 256
): Promise<string> {
  const img = await loadImageElement(imageSrc);
  const canvas = document.createElement('canvas');
  canvas.width = outputSize;
  canvas.height = outputSize;

  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas 2D context unavailable.');
  }

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  const iw = img.naturalWidth || img.width;
  const ih = img.naturalHeight || img.height;

  // Base scale covers the square cleanly (object-cover)
  const baseScale = Math.max(outputSize / iw, outputSize / ih);
  const finalScale = baseScale * Math.max(1, Math.min(3, transform.zoom));

  const drawW = iw * finalScale;
  const drawH = ih * finalScale;

  const maxPanX = Math.max(0, (drawW - outputSize) / 2);
  const maxPanY = Math.max(0, (drawH - outputSize) / 2);

  const centerX = (outputSize - drawW) / 2 + transform.offsetX * maxPanX;
  const centerY = (outputSize - drawH) / 2 + transform.offsetY * maxPanY;

  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, outputSize, outputSize);
  ctx.drawImage(img, centerX, centerY, drawW, drawH);

  return canvas.toDataURL('image/jpeg', 0.86);
}
