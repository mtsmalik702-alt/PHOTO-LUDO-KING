class SoundEffectsManager {
  private ctx: AudioContext | null = null;
  private muted: boolean = false;

  constructor() {
    try {
      this.muted = localStorage.getItem('plk_muted') === '1';
    } catch {
      this.muted = false;
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public toggleMute(): boolean {
    this.muted = !this.muted;
    try {
      localStorage.setItem('plk_muted', this.muted ? '1' : '0');
    } catch {
      // Ignore storage errors
    }
    return this.muted;
  }

  private ensureContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private playTone(
    freq: number,
    durationSec: number,
    type: OscillatorType = 'sine',
    gainPeak = 0.08,
    delaySec = 0
  ): void {
    const ctx = this.ensureContext();
    if (!ctx) return;

    const now = ctx.currentTime + delaySec;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(gainPeak, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + durationSec);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + durationSec + 0.02);
  }

  public playDiceRoll(): void {
    // Tactile wooden dice rattle
    this.playTone(260, 0.05, 'triangle', 0.06, 0);
    this.playTone(340, 0.05, 'triangle', 0.06, 0.055);
    this.playTone(290, 0.05, 'triangle', 0.06, 0.11);
    this.playTone(420, 0.07, 'triangle', 0.07, 0.17);
  }

  public playSixRolled(): void {
    this.playTone(523.25, 0.12, 'triangle', 0.08, 0);
    this.playTone(659.25, 0.16, 'triangle', 0.09, 0.08);
  }

  public playStepHop(): void {
    this.playTone(480, 0.055, 'sine', 0.055, 0);
  }

  public playExitYard(): void {
    this.playTone(440, 0.09, 'triangle', 0.08, 0);
    this.playTone(587.33, 0.13, 'triangle', 0.09, 0.07);
    this.playTone(880, 0.18, 'sine', 0.09, 0.14);
  }

  public playCapture(): void {
    this.playTone(620, 0.08, 'sawtooth', 0.06, 0);
    this.playTone(440, 0.09, 'sawtooth', 0.06, 0.07);
    this.playTone(784, 0.22, 'triangle', 0.09, 0.15);
  }

  public playReachHome(): void {
    this.playTone(523.25, 0.12, 'triangle', 0.09, 0);
    this.playTone(659.25, 0.12, 'triangle', 0.09, 0.09);
    this.playTone(783.99, 0.14, 'triangle', 0.09, 0.18);
    this.playTone(1046.5, 0.28, 'sine', 0.1, 0.27);
  }

  public playVictory(): void {
    const notes = [523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5];
    const delays = [0, 0.11, 0.22, 0.34, 0.5, 0.64];
    notes.forEach((n, i) => {
      this.playTone(n, i === notes.length - 1 ? 0.45 : 0.14, 'triangle', 0.1, delays[i]);
    });
  }
}

export const soundFX = new SoundEffectsManager();
