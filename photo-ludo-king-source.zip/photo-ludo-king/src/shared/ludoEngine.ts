export type PlayerId = 'P1' | 'P2';

export type GameMode = 'LOCAL' | 'ONLINE';

export type TurnPhase = 'WAITING_FOR_PLAYERS' | 'ROLL' | 'MOVE' | 'NO_MOVES' | 'GAME_OVER';

export interface BoardPoint {
  row: number;
  col: number;
}

export interface TokenState {
  id: number; // 0, 1, 2, 3
  step: number; // -1 = in yard, 0..50 = outer track, 51..55 = home stretch, 56 = finished home
}

export interface PlayerProfile {
  id: PlayerId;
  name: string;
  photo: string | null;
  connected: boolean;
}

export interface PlayerStats {
  captures: number;
  sixes: number;
  turns: number;
  finishedCount: number;
}

export interface MoveAnimationData {
  moveId: number;
  player: PlayerId;
  tokenId: number;
  fromStep: number;
  toStep: number;
  pathCoords: BoardPoint[];
  capturedToken?: {
    player: PlayerId;
    tokenId: number;
    atCoord: BoardPoint;
  };
  reachedHome?: boolean;
  bonusRoll?: boolean;
}

export interface HistoryEntry {
  id: number;
  player: PlayerId;
  text: string;
  timestamp: number;
}

export interface LudoGameState {
  mode: GameMode;
  roomCode: string | null;
  phase: TurnPhase;
  turn: PlayerId;
  diceValue: number | null;
  rollCount: number;
  consecutiveSixes: number;
  movableTokenIds: number[];
  winner: PlayerId | null;
  statusMessage: string;
  players: Record<PlayerId, PlayerProfile>;
  tokens: Record<PlayerId, TokenState[]>;
  stats: Record<PlayerId, PlayerStats>;
  lastMove: MoveAnimationData | null;
  history: HistoryEntry[];
}

/**
 * 52-cell clockwise outer Ludo track on a 15x15 grid (0-indexed rows 0..14, cols 0..14).
 * Index 0 is Bottom-Left (Red / P1) start square at (13, 6).
 * Index 26 is Top-Right (Blue / P2) start square at (1, 8).
 */
export const OUTER_TRACK_COORDS: BoardPoint[] = [
  // 0..4: Bottom arm left column going UP
  { row: 13, col: 6 },
  { row: 12, col: 6 },
  { row: 11, col: 6 },
  { row: 10, col: 6 },
  { row: 9, col: 6 },
  // 5..10: Left arm bottom row going LEFT
  { row: 8, col: 5 },
  { row: 8, col: 4 },
  { row: 8, col: 3 },
  { row: 8, col: 2 }, // 8: Safe Star
  { row: 8, col: 1 },
  { row: 8, col: 0 },
  // 11: Left arm outer middle
  { row: 7, col: 0 },
  // 12..17: Left arm top row going RIGHT
  { row: 6, col: 0 },
  { row: 6, col: 1 }, // 13: Green Start (Safe)
  { row: 6, col: 2 },
  { row: 6, col: 3 },
  { row: 6, col: 4 },
  { row: 6, col: 5 },
  // 18..23: Top arm left column going UP
  { row: 5, col: 6 },
  { row: 4, col: 6 },
  { row: 3, col: 6 },
  { row: 2, col: 6 }, // 21: Safe Star
  { row: 1, col: 6 },
  { row: 0, col: 6 },
  // 24: Top arm outer middle (Blue turns down after this!)
  { row: 0, col: 7 },
  // 25..30: Top arm right column going DOWN
  { row: 0, col: 8 },
  { row: 1, col: 8 }, // 26: Blue Start (P2 Safe)
  { row: 2, col: 8 },
  { row: 3, col: 8 },
  { row: 4, col: 8 },
  { row: 5, col: 8 },
  // 31..36: Right arm top row going RIGHT
  { row: 6, col: 9 },
  { row: 6, col: 10 },
  { row: 6, col: 11 },
  { row: 6, col: 12 }, // 34: Safe Star
  { row: 6, col: 13 },
  { row: 6, col: 14 },
  // 37: Right arm outer middle
  { row: 7, col: 14 },
  // 38..43: Right arm bottom row going LEFT
  { row: 8, col: 14 },
  { row: 8, col: 13 }, // 39: Amber Start (Safe)
  { row: 8, col: 12 },
  { row: 8, col: 11 },
  { row: 8, col: 10 },
  { row: 8, col: 9 },
  // 44..49: Bottom arm right column going DOWN
  { row: 9, col: 8 },
  { row: 10, col: 8 },
  { row: 11, col: 8 },
  { row: 12, col: 8 }, // 47: Safe Star
  { row: 13, col: 8 },
  { row: 14, col: 8 },
  // 50..51: Bottom arm outer end going LEFT (Red turns up after 50!)
  { row: 14, col: 7 },
  { row: 14, col: 6 },
];

export const SAFE_TRACK_INDICES = new Set<number>([0, 8, 13, 21, 26, 34, 39, 47]);

export const PLAYER_START_INDEX: Record<PlayerId, number> = {
  P1: 0,
  P2: 26,
};

export const HOME_STRETCH_COORDS: Record<PlayerId, BoardPoint[]> = {
  // steps 51..55
  P1: [
    { row: 13, col: 7 },
    { row: 12, col: 7 },
    { row: 11, col: 7 },
    { row: 10, col: 7 },
    { row: 9, col: 7 },
  ],
  P2: [
    { row: 1, col: 7 },
    { row: 2, col: 7 },
    { row: 3, col: 7 },
    { row: 4, col: 7 },
    { row: 5, col: 7 },
  ],
};

export const YARD_DOCK_COORDS: Record<PlayerId, BoardPoint[]> = {
  P1: [
    { row: 10.6, col: 1.6 },
    { row: 10.6, col: 3.4 },
    { row: 12.4, col: 1.6 },
    { row: 12.4, col: 3.4 },
  ],
  P2: [
    { row: 1.6, col: 10.6 },
    { row: 1.6, col: 12.4 },
    { row: 3.4, col: 10.6 },
    { row: 3.4, col: 12.4 },
  ],
};

export const HOME_FINISH_COORDS: Record<PlayerId, BoardPoint[]> = {
  P1: [
    { row: 8.18, col: 6.55 },
    { row: 8.18, col: 6.85 },
    { row: 8.18, col: 7.15 },
    { row: 8.18, col: 7.45 },
  ],
  P2: [
    { row: 5.82, col: 6.55 },
    { row: 5.82, col: 6.85 },
    { row: 5.82, col: 7.15 },
    { row: 5.82, col: 7.45 },
  ],
};

export function getGlobalTrackIndex(player: PlayerId, step: number): number | null {
  if (step < 0 || step > 50) return null;
  return (PLAYER_START_INDEX[player] + step) % 52;
}

export function getTokenBoardCoord(player: PlayerId, tokenId: number, step: number): BoardPoint {
  if (step === -1) {
    return YARD_DOCK_COORDS[player][tokenId];
  }
  if (step >= 0 && step <= 50) {
    const idx = getGlobalTrackIndex(player, step)!;
    return OUTER_TRACK_COORDS[idx];
  }
  if (step >= 51 && step <= 55) {
    return HOME_STRETCH_COORDS[player][step - 51];
  }
  return HOME_FINISH_COORDS[player][tokenId];
}

export function getOpponent(player: PlayerId): PlayerId {
  return player === 'P1' ? 'P2' : 'P1';
}

export function createInitialTokens(): TokenState[] {
  return [
    { id: 0, step: -1 },
    { id: 1, step: -1 },
    { id: 2, step: -1 },
    { id: 3, step: -1 },
  ];
}

export function createInitialGameState(
  mode: GameMode,
  roomCode: string | null = null,
  p1Profile?: Partial<PlayerProfile>,
  p2Profile?: Partial<PlayerProfile>
): LudoGameState {
  const isWaiting = mode === 'ONLINE';
  const p1Name = p1Profile?.name?.trim() || 'Player 1';
  const p2Name = p2Profile?.name?.trim() || (mode === 'ONLINE' ? 'Waiting for Friend' : 'Player 2');

  return {
    mode,
    roomCode,
    phase: isWaiting ? 'WAITING_FOR_PLAYERS' : 'ROLL',
    turn: 'P1',
    diceValue: null,
    rollCount: 0,
    consecutiveSixes: 0,
    movableTokenIds: [],
    winner: null,
    statusMessage: isWaiting
      ? 'Share your room code with a friend to start!'
      : `${p1Name}'s turn — tap Roll Dice!`,
    players: {
      P1: {
        id: 'P1',
        name: p1Name,
        photo: p1Profile?.photo ?? null,
        connected: true,
      },
      P2: {
        id: 'P2',
        name: p2Name,
        photo: p2Profile?.photo ?? null,
        connected: mode === 'LOCAL',
      },
    },
    tokens: {
      P1: createInitialTokens(),
      P2: createInitialTokens(),
    },
    stats: {
      P1: { captures: 0, sixes: 0, turns: 0, finishedCount: 0 },
      P2: { captures: 0, sixes: 0, turns: 0, finishedCount: 0 },
    },
    lastMove: null,
    history: [],
  };
}

export function getMovableTokenIds(
  state: LudoGameState,
  player: PlayerId,
  diceValue: number
): number[] {
  const playerTokens = state.tokens[player];
  const movable: number[] = [];

  for (const token of playerTokens) {
    if (token.step === -1) {
      if (diceValue === 6) {
        movable.push(token.id);
      }
    } else if (token.step >= 0 && token.step < 56) {
      if (token.step + diceValue <= 56) {
        movable.push(token.id);
      }
    }
  }
  return movable;
}

function appendHistory(state: LudoGameState, player: PlayerId, text: string): HistoryEntry[] {
  const nextEntry: HistoryEntry = {
    id: (state.history[0]?.id ?? 0) + 1,
    player,
    text,
    timestamp: Date.now(),
  };
  return [nextEntry, ...state.history].slice(0, 18);
}

export function applyDiceRoll(
  state: LudoGameState,
  player: PlayerId,
  forcedDice?: number
): LudoGameState {
  if (state.phase !== 'ROLL' || state.turn !== player) {
    return state;
  }

  const dice = forcedDice ?? Math.floor(Math.random() * 6) + 1;
  const pName = state.players[player].name;
  const opponent = getOpponent(player);
  const oppName = state.players[opponent].name;

  const nextRollCount = state.rollCount + 1;
  const nextConsecutiveSixes = dice === 6 ? state.consecutiveSixes + 1 : 0;

  const updatedStats: Record<PlayerId, PlayerStats> = {
    ...state.stats,
    [player]: {
      ...state.stats[player],
      turns: state.stats[player].turns + 1,
      sixes: state.stats[player].sixes + (dice === 6 ? 1 : 0),
    },
  };

  // Three consecutive 6s rule: forfeit move and pass turn
  if (nextConsecutiveSixes >= 3) {
    return {
      ...state,
      diceValue: dice,
      rollCount: nextRollCount,
      consecutiveSixes: 0,
      phase: 'NO_MOVES',
      movableTokenIds: [],
      stats: updatedStats,
      statusMessage: `Three 6s in a row! Turn passes to ${oppName}.`,
      history: appendHistory(state, player, `Rolled three 6s in a row — turn passed`),
    };
  }

  const movable = getMovableTokenIds(state, player, dice);

  if (movable.length === 0) {
    return {
      ...state,
      diceValue: dice,
      rollCount: nextRollCount,
      consecutiveSixes: 0,
      phase: 'NO_MOVES',
      movableTokenIds: [],
      stats: updatedStats,
      statusMessage: `${pName} rolled ${dice} — no valid moves.`,
      history: appendHistory(state, player, `Rolled ${dice} (no available moves)`),
    };
  }

  return {
    ...state,
    diceValue: dice,
    rollCount: nextRollCount,
    consecutiveSixes: nextConsecutiveSixes,
    phase: 'MOVE',
    movableTokenIds: movable,
    stats: updatedStats,
    statusMessage:
      movable.length === 1
        ? `${pName} rolled ${dice} — tap your highlighted photo token!`
        : `${pName} rolled ${dice} — choose a photo token to move!`,
  };
}

export function advanceAfterNoMoves(state: LudoGameState): LudoGameState {
  if (state.phase !== 'NO_MOVES') {
    return state;
  }
  const nextTurn = getOpponent(state.turn);
  const nextName = state.players[nextTurn].name;
  return {
    ...state,
    phase: 'ROLL',
    turn: nextTurn,
    diceValue: null,
    consecutiveSixes: 0,
    movableTokenIds: [],
    statusMessage: `${nextName}'s turn — tap Roll Dice!`,
  };
}

export function applyTokenMove(
  state: LudoGameState,
  player: PlayerId,
  tokenId: number
): LudoGameState {
  if (state.phase !== 'MOVE' || state.turn !== player || state.diceValue === null) {
    return state;
  }
  if (!state.movableTokenIds.includes(tokenId)) {
    return state;
  }

  const dice = state.diceValue;
  const currentTokens = state.tokens[player];
  const targetToken = currentTokens.find((t) => t.id === tokenId);
  if (!targetToken) return state;

  const fromStep = targetToken.step;
  const toStep = fromStep === -1 ? 0 : fromStep + dice;

  // Build step-by-step path coordinates for smooth board hop animation
  const pathCoords: BoardPoint[] = [];
  if (fromStep === -1) {
    pathCoords.push(getTokenBoardCoord(player, tokenId, -1));
    pathCoords.push(getTokenBoardCoord(player, tokenId, 0));
  } else {
    for (let s = fromStep; s <= toStep; s++) {
      pathCoords.push(getTokenBoardCoord(player, tokenId, s));
    }
  }

  const nextPlayerTokens = currentTokens.map((t) =>
    t.id === tokenId ? { ...t, step: toStep } : t
  );

  const opponent = getOpponent(player);
  let nextOpponentTokens = state.tokens[opponent];
  let capturedToken: MoveAnimationData['capturedToken'] | undefined;

  // Check capture on outer track (0..50) if square is NOT a safe square
  if (toStep >= 0 && toStep <= 50) {
    const destGlobalIdx = getGlobalTrackIndex(player, toStep)!;
    if (!SAFE_TRACK_INDICES.has(destGlobalIdx)) {
      const oppTokensAtSquare = nextOpponentTokens.filter((ot) => {
        if (ot.step < 0 || ot.step > 50) return false;
        return getGlobalTrackIndex(opponent, ot.step) === destGlobalIdx;
      });

      // Capture opponent token if present
      if (oppTokensAtSquare.length > 0) {
        const victim = oppTokensAtSquare[0];
        capturedToken = {
          player: opponent,
          tokenId: victim.id,
          atCoord: OUTER_TRACK_COORDS[destGlobalIdx],
        };
        nextOpponentTokens = nextOpponentTokens.map((ot) =>
          ot.id === victim.id ? { ...ot, step: -1 } : ot
        );
      }
    }
  }

  const reachedHome = toStep === 56;
  const finishedCount = nextPlayerTokens.filter((t) => t.step === 56).length;
  const hasWon = finishedCount === 4;

  const updatedStats: Record<PlayerId, PlayerStats> = {
    ...state.stats,
    [player]: {
      ...state.stats[player],
      captures: state.stats[player].captures + (capturedToken ? 1 : 0),
      finishedCount,
    },
  };

  const pName = state.players[player].name;
  const oppName = state.players[opponent].name;
  const bonusRoll = !hasWon && (dice === 6 || Boolean(capturedToken) || reachedHome);

  const moveId = (state.lastMove?.moveId ?? 0) + 1;
  const lastMove: MoveAnimationData = {
    moveId,
    player,
    tokenId,
    fromStep,
    toStep,
    pathCoords,
    capturedToken,
    reachedHome,
    bonusRoll,
  };

  let historyNote =
    fromStep === -1
      ? `Rolled 6 & brought Token #${tokenId + 1} onto the board`
      : `Moved Token #${tokenId + 1} by ${dice} steps`;

  if (capturedToken) {
    historyNote = `Captured ${oppName}'s photo token! Bonus roll`;
  } else if (reachedHome) {
    historyNote = `Token #${tokenId + 1} reached Home Crown! (${finishedCount}/4)`;
  }

  if (hasWon) {
    return {
      ...state,
      phase: 'GAME_OVER',
      winner: player,
      diceValue: dice,
      movableTokenIds: [],
      consecutiveSixes: 0,
      tokens: {
        ...state.tokens,
        [player]: nextPlayerTokens,
        [opponent]: nextOpponentTokens,
      },
      stats: updatedStats,
      lastMove,
      statusMessage: `${pName} wins the match and becomes Photo Ludo King!`,
      history: appendHistory(state, player, `Won the match! All 4 photo tokens reached Home!`),
    };
  }

  const nextTurn = bonusRoll ? player : opponent;
  const nextTurnName = state.players[nextTurn].name;

  let statusMessage = `${nextTurnName}'s turn — tap Roll Dice!`;
  if (capturedToken) {
    statusMessage = `Captured ${oppName}'s token! ${pName} gets a bonus roll!`;
  } else if (reachedHome) {
    statusMessage = `Token reached Home! ${pName} gets a bonus roll!`;
  } else if (dice === 6) {
    statusMessage = `Rolled a 6! ${pName} gets a bonus roll!`;
  }

  return {
    ...state,
    phase: 'ROLL',
    turn: nextTurn,
    diceValue: null,
    movableTokenIds: [],
    consecutiveSixes: bonusRoll && dice === 6 ? state.consecutiveSixes : 0,
    tokens: {
      ...state.tokens,
      [player]: nextPlayerTokens,
      [opponent]: nextOpponentTokens,
    },
    stats: updatedStats,
    lastMove,
    statusMessage,
    history: appendHistory(state, player, historyNote),
  };
}

/**
 * Allows changing a player's uploaded photo or name ANYTIME (lobby, mid-game, or winner screen).
 */
export function updatePlayerProfile(
  state: LudoGameState,
  player: PlayerId,
  updates: { name?: string; photo?: string | null }
): LudoGameState {
  const current = state.players[player];
  const nextName =
    updates.name !== undefined && updates.name.trim().length > 0
      ? updates.name.trim().slice(0, 20)
      : current.name;
  const nextPhoto = updates.photo !== undefined ? updates.photo : current.photo;

  const nextPlayers: Record<PlayerId, PlayerProfile> = {
    ...state.players,
    [player]: {
      ...current,
      name: nextName,
      photo: nextPhoto,
    },
  };

  let nextStatus = state.statusMessage;
  if (state.phase === 'ROLL' && state.turn === player) {
    nextStatus = `${nextName}'s turn — tap Roll Dice!`;
  }

  return {
    ...state,
    players: nextPlayers,
    statusMessage: nextStatus,
  };
}

export function resetMatchKeepProfiles(state: LudoGameState): LudoGameState {
  const bothReady =
    state.mode === 'LOCAL' || (state.players.P1.connected && state.players.P2.connected);
  const starter: PlayerId = state.winner ? getOpponent(state.winner) : 'P1';
  const starterName = state.players[starter].name;

  return {
    ...state,
    phase: bothReady ? 'ROLL' : 'WAITING_FOR_PLAYERS',
    turn: starter,
    diceValue: null,
    rollCount: 0,
    consecutiveSixes: 0,
    movableTokenIds: [],
    winner: null,
    statusMessage: bothReady
      ? `New match started! ${starterName} rolls first.`
      : 'Waiting for friend to reconnect...',
    tokens: {
      P1: createInitialTokens(),
      P2: createInitialTokens(),
    },
    stats: {
      P1: { captures: 0, sixes: 0, turns: 0, finishedCount: 0 },
      P2: { captures: 0, sixes: 0, turns: 0, finishedCount: 0 },
    },
    lastMove: null,
    history: [],
  };
}

/**
 * Helper to let a quick Demo Bot or hint pick the smartest movable token.
 */
export function chooseBestMoveTokenId(state: LudoGameState, player: PlayerId): number | null {
  if (state.phase !== 'MOVE' || state.diceValue === null || state.movableTokenIds.length === 0) {
    return null;
  }
  const dice = state.diceValue;
  const opponent = getOpponent(player);
  const oppTokens = state.tokens[opponent];

  let bestId = state.movableTokenIds[0];
  let bestScore = -1000;

  for (const id of state.movableTokenIds) {
    const token = state.tokens[player].find((t) => t.id === id)!;
    const toStep = token.step === -1 ? 0 : token.step + dice;
    let score = toStep;

    if (toStep === 56) score += 500; // Finishing home is top priority
    if (toStep >= 0 && toStep <= 50) {
      const destIdx = getGlobalTrackIndex(player, toStep)!;
      if (!SAFE_TRACK_INDICES.has(destIdx)) {
        const canCapture = oppTokens.some(
          (ot) => ot.step >= 0 && ot.step <= 50 && getGlobalTrackIndex(opponent, ot.step) === destIdx
        );
        if (canCapture) score += 400;
      } else {
        score += 45; // Landing on a safe square
      }
    }
    if (token.step === -1 && dice === 6) {
      score += 120; // Exiting yard
    }
    if (score > bestScore) {
      bestScore = score;
      bestId = id;
    }
  }
  return bestId;
}
