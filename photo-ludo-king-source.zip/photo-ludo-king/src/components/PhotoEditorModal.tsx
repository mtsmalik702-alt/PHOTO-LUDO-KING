import React, { useState, useRef, useEffect } from 'react';
import { X, Upload, ZoomIn, RotateCcw, Check, Image as ImageIcon } from 'lucide-react';
import type { GameMode, PlayerId, PlayerProfile } from '../shared/ludoEngine';
import { readFileAsDataUrl, renderSquareTokenPhoto } from '../utils/photoUtils';
import type { CropTransform } from '../utils/photoUtils';
import { PlayerAvatarImg } from './PlayerAvatarImg';

interface PhotoEditorModalProps {
  isOpen: boolean;
  initialPlayer: PlayerId;
  mode: GameMode;
  onlineSeat: PlayerId | null;
  players: Record<PlayerId, PlayerProfile>;
  onSaveProfile: (player: PlayerId, updates: { name?: string; photo?: string | null }) => void;
  onClose: () => void;
}

export const PhotoEditorModal: React.FC<PhotoEditorModalProps> = ({
  isOpen,
  initialPlayer,
  mode,
  onlineSeat,
  players,
  onSaveProfile,
  onClose,
}) => {
  const [activePlayer, setActivePlayer] = useState<PlayerId>(initialPlayer);
  const [nameInput, setNameInput] = useState('');
  const [rawImageSrc, setRawImageSrc] = useState<string | null>(null);
  const [previewPhoto, setPreviewPhoto] = useState<string | null>(null);
  const [crop, setCrop] = useState<CropTransform>({ zoom: 1.05, offsetX: 0, offsetY: 0 });
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const dragStartRef = useRef<{ x: number; y: number; startX: number; startY: number } | null>(
    null
  );

  useEffect(() => {
    if (isOpen) {
      const target = mode === 'ONLINE' && onlineSeat ? onlineSeat : initialPlayer;
      setActivePlayer(target);
    }
  }, [isOpen, initialPlayer, mode, onlineSeat]);

  useEffect(() => {
    if (!isOpen) return;
    const p = players[activePlayer];
    setNameInput(p.name === 'Waiting for Friend' ? 'Player 2' : p.name);
    setRawImageSrc(null);
    setPreviewPhoto(p.photo);
    setCrop({ zoom: 1.05, offsetX: 0, offsetY: 0 });
    setErrorMsg(null);
  }, [isOpen, activePlayer, players]);

  // Update live square preview whenever user adjusts zoom/pan on newly selected gallery photo
  useEffect(() => {
    if (!rawImageSrc) return;
    let cancelled = false;
    renderSquareTokenPhoto(rawImageSrc, crop, 256)
      .then((cropped) => {
        if (!cancelled) setPreviewPhoto(cropped);
      })
      .catch(() => {
        if (!cancelled) setErrorMsg('Could not frame this image. Please try another photo.');
      });
    return () => {
      cancelled = true;
    };
  }, [rawImageSrc, crop]);

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMsg(null);

    try {
      const dataUrl = await readFileAsDataUrl(file);
      setRawImageSrc(dataUrl);
      setCrop({ zoom: 1.1, offsetX: 0, offsetY: 0 });
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to load gallery photo.');
    } finally {
      e.target.value = '';
    }
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!rawImageSrc) return;
    e.currentTarget.setPointerCapture(e.pointerId);
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      startX: crop.offsetX,
      startY: crop.offsetY,
    };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragStartRef.current || !rawImageSrc) return;
    const dx = (e.clientX - dragStartRef.current.x) / 90;
    const dy = (e.clientY - dragStartRef.current.y) / 90;
    setCrop((prev) => ({
      ...prev,
      offsetX: Math.max(-1, Math.min(1, dragStartRef.current!.startX + dx)),
      offsetY: Math.max(-1, Math.min(1, dragStartRef.current!.startY + dy)),
    }));
  };

  const handlePointerUp = () => {
    dragStartRef.current = null;
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      let finalPhoto = previewPhoto;
      if (rawImageSrc) {
        finalPhoto = await renderSquareTokenPhoto(rawImageSrc, crop, 256);
      }
      onSaveProfile(activePlayer, {
        name: nameInput.trim() || (activePlayer === 'P1' ? 'Player 1' : 'Player 2'),
        photo: finalPhoto,
      });
      onClose();
    } catch {
      setErrorMsg('Failed to process photo.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetDefaultPhoto = () => {
    setRawImageSrc(null);
    setPreviewPhoto(null);
  };

  const isP1 = activePlayer === 'P1';
  const accentRing = isP1 ? 'bg-rose-600' : 'bg-blue-600';

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="photo-editor-title"
    >
      <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[92vh] flex flex-col">
        {/* Mobile Sheet Grab Handle */}
        <div className="w-10 h-1.5 bg-slate-200 rounded-full mx-auto mt-2.5 sm:hidden shrink-0" />

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 shrink-0">
          <h2
            id="photo-editor-title"
            className="font-display font-bold text-lg text-slate-900"
          >
            Customize Token Photo
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[44px] min-h-[44px] -mr-2 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition-colors touch-manipulation"
            aria-label="Close photo studio"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-5">
          {/* In Local 2-Player mode, allow switching between Player 1 & Player 2 seamlessly */}
          {mode === 'LOCAL' && (
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 rounded-xl">
              <button
                type="button"
                onClick={() => setActivePlayer('P1')}
                className={`min-h-[44px] px-3 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap touch-manipulation ${
                  isP1
                    ? 'bg-rose-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Player 1 (Red)
              </button>
              <button
                type="button"
                onClick={() => setActivePlayer('P2')}
                className={`min-h-[44px] px-3 py-2 rounded-lg text-sm font-semibold transition-colors whitespace-nowrap touch-manipulation ${
                  !isP1
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Player 2 (Blue)
              </button>
            </div>
          )}

          {/* Hidden Native Gallery File Picker (works seamlessly on Android & iOS galleries) */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />

          {/* Main Circular Token Preview + Drag Framing */}
          <div className="flex flex-col items-center">
            <div
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerUp}
              className={`relative w-32 h-32 rounded-full p-1.5 ${accentRing} shadow-lg ${
                rawImageSrc ? 'cursor-grab active:cursor-grabbing touch-none' : ''
              }`}
            >
              <div className="w-full h-full rounded-full overflow-hidden bg-white ring-2 ring-white">
                <PlayerAvatarImg
                  player={activePlayer}
                  photo={previewPhoto}
                  name={nameInput || activePlayer}
                />
              </div>
            </div>

            {rawImageSrc ? (
              <p className="text-xs text-slate-500 mt-2">
                Drag photo to center your face · Adjust zoom below
              </p>
            ) : (
              <p className="text-xs text-slate-500 mt-2">
                Your photo appears on all 4 {isP1 ? 'Red' : 'Blue'} tokens
              </p>
            )}
          </div>

          {/* Zoom Slider when framing a newly uploaded gallery photo */}
          {rawImageSrc && (
            <div className="flex items-center gap-3 px-3 py-2.5 bg-slate-50 rounded-xl border border-slate-200/80">
              <ZoomIn className="w-4 h-4 text-slate-500 shrink-0" />
              <input
                type="range"
                min={1}
                max={2.6}
                step={0.05}
                value={crop.zoom}
                onChange={(e) =>
                  setCrop((prev) => ({ ...prev, zoom: parseFloat(e.target.value) }))
                }
                aria-label="Zoom token photo"
                className="w-full accent-slate-900 h-2 cursor-pointer"
              />
            </div>
          )}

          {/* Primary Upload From Phone Gallery CTA */}
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className={`flex-1 min-h-[48px] px-4 py-3 rounded-xl font-semibold text-sm text-white flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] transition-transform whitespace-nowrap touch-manipulation ${
                isP1 ? 'bg-rose-600 hover:bg-rose-700' : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              <Upload className="w-4 h-4 shrink-0" />
              <span>Choose from Phone Gallery</span>
            </button>

            {previewPhoto && (
              <button
                type="button"
                onClick={handleResetDefaultPhoto}
                title="Reset to default avatar"
                className="min-w-[48px] min-h-[48px] rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 flex items-center justify-center transition-colors touch-manipulation"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Live 4-Token Strip Preview */}
          <div className="pt-1">
            <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
              <span className="flex items-center gap-1.5 font-medium text-slate-700">
                <ImageIcon className="w-3.5 h-3.5 text-slate-400" />
                Live Preview on All 4 Tokens
              </span>
              <span>#{isP1 ? 'Red' : 'Blue'} Squad</span>
            </div>
            <div className="grid grid-cols-4 gap-3 py-3 px-4 rounded-2xl bg-slate-50 border border-slate-200/80 justify-items-center">
              {[1, 2, 3, 4].map((num) => (
                <div key={num} className="relative w-12 h-12">
                  <div
                    className={`w-full h-full rounded-full p-1 ${accentRing} shadow-sm`}
                  >
                    <div className="w-full h-full rounded-full overflow-hidden bg-white ring-1 ring-white">
                      <PlayerAvatarImg
                        player={activePlayer}
                        photo={previewPhoto}
                        name={nameInput || activePlayer}
                      />
                    </div>
                  </div>
                  <span
                    className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full text-[9px] font-mono font-bold text-white flex items-center justify-center ${
                      isP1 ? 'bg-rose-700' : 'bg-blue-700'
                    }`}
                  >
                    {num}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Player Display Name Input */}
          <div>
            <label
              htmlFor="player-name-input"
              className="block text-xs font-semibold text-slate-700 mb-1.5"
            >
              Player Name
            </label>
            <input
              id="player-name-input"
              type="text"
              maxLength={18}
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              placeholder={isP1 ? 'Player 1' : 'Player 2'}
              className="w-full min-h-[46px] px-3.5 py-2 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          {errorMsg && (
            <p className="text-xs font-medium text-rose-600">{errorMsg}</p>
          )}
        </div>

        {/* Sticky Bottom Action Bar */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/70 flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[48px] px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-700 text-sm font-semibold hover:bg-slate-50 transition-colors whitespace-nowrap touch-manipulation"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={isSaving}
            onClick={handleSave}
            className="flex-1 min-h-[48px] px-5 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-semibold hover:bg-slate-800 active:scale-[0.99] transition-all flex items-center justify-center gap-2 whitespace-nowrap touch-manipulation"
          >
            <Check className="w-4 h-4 shrink-0" />
            <span>Save Photo & Apply Now</span>
          </button>
        </div>
      </div>
    </div>
  );
};
