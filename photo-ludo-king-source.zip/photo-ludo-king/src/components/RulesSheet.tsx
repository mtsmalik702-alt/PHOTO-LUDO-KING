import React from 'react';
import { X, BookOpen } from 'lucide-react';

interface RulesSheetProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesSheet: React.FC<RulesSheetProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const rules = [
    {
      title: '01. Photo Squads & Setup',
      body: 'Upload any photo from your phone gallery—your photo appears on all 4 of your Ludo tokens. You can change your photo anytime before or during a match.',
    },
    {
      title: '02. Leaving the Yard (Roll a 6)',
      body: 'Roll a 6 to bring a photo token out of your corner yard onto your colored start square, or move an active token 6 steps forward.',
    },
    {
      title: '03. Bonus Rolls & Three-6s Limit',
      body: 'Rolling a 6, capturing an opponent token, or reaching the center Home Crown grants an extra roll. Rolling three 6s in a row passes the turn.',
    },
    {
      title: '04. Capturing & Safe Star Squares',
      body: 'Landing on an opponent token sends it back to their yard—unless it rests on one of the 8 Safe Squares (the 4 colored start arrows and 4 star tiles).',
    },
    {
      title: '05. Winning Photo Ludo King',
      body: 'Guide your tokens clockwise around the 52-tile track and up your colored home column with an exact roll. First player to bring all 4 photo tokens home wins!',
    },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="rules-sheet-title"
    >
      <div className="w-full sm:max-w-lg bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden max-h-[88vh] flex flex-col">
        <div className="w-10 h-1.5 bg-slate-200 rounded-full mx-auto mt-2.5 sm:hidden shrink-0" />

        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-slate-700" />
            <h2 id="rules-sheet-title" className="font-display font-bold text-lg text-slate-900">
              How to Play Photo Ludo King
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[44px] min-h-[44px] -mr-2 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100 transition-colors touch-manipulation"
            aria-label="Close rules"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto divide-y divide-slate-100">
          {rules.map((rule) => (
            <div key={rule.title} className="py-3.5 first:pt-0 last:pb-0">
              <h3 className="font-display font-bold text-sm text-slate-900">
                {rule.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mt-1">
                {rule.body}
              </p>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50/70 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="w-full min-h-[48px] px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold transition-colors whitespace-nowrap touch-manipulation"
          >
            Got It — Back to Game
          </button>
        </div>
      </div>
    </div>
  );
};
