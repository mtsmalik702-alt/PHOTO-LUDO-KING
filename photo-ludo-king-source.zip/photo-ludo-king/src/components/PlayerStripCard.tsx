import React from 'react';
import { Camera, Crown } from 'lucide-react';
import type { LudoGameState, PlayerId } from '../shared/ludoEngine';
import { PlayerAvatarImg } from './PlayerAvatarImg';

interface PlayerStripCardProps {
  player: PlayerId;
  gameState: LudoGameState;
  isMyOnlineSeat: boolean;
  canEditPhoto: boolean;
  onEditPhoto: (player: PlayerId) => void;
}

export const PlayerStripCard: React.FC<PlayerStripCardProps> = ({
  player,
  gameState,
  isMyOnlineSeat,
  canEditPhoto,
  onEditPhoto,
}) => {
  const profile = gameState.players[player];
  const stats = gameState.stats[player];
  const tokens = gameState.tokens[player];
  const isTurn = gameState.turn === player && gameState.phase !== 'GAME_OVER';
  const isP1 = player === 'P1';

  const activeFrameClass = isTurn
    ? isP1
      ? 'border-rose-500 bg-rose-50/40 shadow-sm'
      : 'border-blue-600 bg-blue-50/40 shadow-sm'
    : 'border-slate-200 bg-white';

  const ringClass = isP1 ? 'bg-rose-600' : 'bg-blue-600';

  return (
    <div
      className={`rounded-2xl border p-3 sm:p-3.5 transition-colors duration-150 ${activeFrameClass}`}
    >
      <div className="flex items-center justify-between gap-3">
        {/* Left: Avatar + One-Tap Change Photo Trigger + Name & Clean Metadata */}
        <div className="flex items-center gap-3 min-w-0">
          <div className="relative shrink-0">
            <button
              type="button"
              disabled={!canEditPhoto}
              onClick={() => canEditPhoto && onEditPhoto(player)}
              title={canEditPhoto ? `Change ${profile.name}'s photo` : profile.name}
              className={`relative w-12 h-12 sm:w-14 sm:h-14 rounded-full p-1 ${ringClass} shadow-sm block touch-manipulation ${
                canEditPhoto ? 'cursor-pointer active:scale-95 transition-transform' : 'cursor-default'
              }`}
            >
              <div className="w-full h-full rounded-full overflow-hidden bg-white ring-1 ring-white">
                <PlayerAvatarImg
                  player={player}
                  photo={profile.photo}
                  name={profile.name}
                />
              </div>
              {canEditPhoto && (
                <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-slate-900 text-white border-2 border-white flex items-center justify-center shadow">
                  <Camera className="w-3 h-3" />
                </span>
              )}
            </button>
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h3 className="font-display font-bold text-sm sm:text-base text-slate-900 truncate">
                {profile.name}
              </h3>
              {isMyOnlineSeat && (
                <span className="text-xs font-medium text-slate-500 shrink-0">(You)</span>
              )}
            </div>

            {/* Clean unboxed metadata per Zero-Pill rule */}
            <div className="flex items-center flex-wrap gap-x-1.5 gap-y-0.5 text-xs text-slate-500 font-mono tabular-nums mt-0.5">
              <span className={isP1 ? 'text-rose-700 font-semibold font-sans' : 'text-blue-700 font-semibold font-sans'}>
                {isTurn ? 'Active Turn' : isP1 ? 'Red Squad' : 'Blue Squad'}
              </span>
              <span aria-hidden="true">·</span>
              <span>Home {stats.finishedCount}/4</span>
              <span aria-hidden="true">·</span>
              <span>Cuts {stats.captures}</span>
            </div>
          </div>
        </div>

        {/* Right: 4 Photo Token Mini Indicators + Quick Photo Action */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="hidden xs:flex sm:flex items-center -space-x-1.5">
            {tokens.map((t) => {
              const isFinished = t.step === 56;
              const isOut = t.step >= 0 && t.step < 56;
              return (
                <div
                  key={t.id}
                  title={
                    isFinished
                      ? `Token #${t.id + 1}: Home`
                      : isOut
                      ? `Token #${t.id + 1}: On Track`
                      : `Token #${t.id + 1}: In Yard`
                  }
                  className={`relative w-7 h-7 rounded-full p-[1.5px] ${ringClass} ring-2 ring-white ${
                    t.step === -1 ? 'opacity-55' : 'opacity-100'
                  }`}
                >
                  <div className="w-full h-full rounded-full overflow-hidden bg-white">
                    <PlayerAvatarImg
                      player={player}
                      photo={profile.photo}
                      name={profile.name}
                    />
                  </div>
                  {isFinished && (
                    <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center">
                      <Crown className="w-2 h-2" />
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {canEditPhoto && (
            <button
              type="button"
              onClick={() => onEditPhoto(player)}
              className="min-h-[44px] px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 transition-colors whitespace-nowrap shrink-0 touch-manipulation"
            >
              Photo
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
