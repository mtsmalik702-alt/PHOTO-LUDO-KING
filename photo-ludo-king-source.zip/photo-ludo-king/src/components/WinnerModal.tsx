import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Crown, RotateCcw, Camera, Users } from 'lucide-react';
import type { LudoGameState, PlayerId } from '../shared/ludoEngine';
import { PlayerAvatarImg } from './PlayerAvatarImg';
import { soundFX } from '../utils/soundEffects';

interface WinnerModalProps {
  gameState: LudoGameState;
  canEditWinnerPhoto: boolean;
  onPlayAgain: () => void;
  onChangeWinnerPhoto: (player: PlayerId) => void;
  onOpenRoomMenu: () => void;
}

export const WinnerModal: React.FC<WinnerModalProps> = ({
  gameState,
  canEditWinnerPhoto,
  onPlayAgain,
  onChangeWinnerPhoto,
  onOpenRoomMenu,
}) => {
  const winner = gameState.winner;

  useEffect(() => {
    if (gameState.phase !== 'GAME_OVER' || !winner) return;

    soundFX.playVictory();
    try {
      confetti({
        particleCount: 90,
        spread: 75,
        origin: { y: 0.58 },
      });
    } catch {
      // Ignore confetti errors in restricted environments
    }
  }, [gameState.phase, winner]);

  if (gameState.phase !== 'GAME_OVER' || !winner) {
    return null;
  }

  const winProfile = gameState.players[winner];
  const winStats = gameState.stats[winner];
  const runnerUp: PlayerId = winner === 'P1' ? 'P2' : 'P1';
  const runnerStats = gameState.stats[runnerUp];
  const isP1 = winner === 'P1';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="winner-screen-title"
    >
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden p-6 text-center space-y-5">
        {/* Crown & Winner Photo Medallion */}
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mb-2 shadow-sm">
            <Crown className="w-7 h-7 fill-amber-400" />
          </div>

          <p className="text-xs font-semibold text-amber-600 tracking-wide">
            Match Champion · Photo Ludo King
          </p>
          <h2
            id="winner-screen-title"
            className="font-display font-extrabold text-2xl sm:text-3xl text-slate-900 mt-0.5 text-balance"
          >
            {winProfile.name} Wins!
          </h2>

          {/* Large Crowned Photo */}
          <div
            className={`relative w-28 h-28 rounded-full p-1.5 mt-4 shadow-xl ${
              isP1 ? 'bg-rose-600' : 'bg-blue-600'
            }`}
          >
            <div className="w-full h-full rounded-full overflow-hidden bg-white ring-2 ring-amber-300">
              <PlayerAvatarImg
                player={winner}
                photo={winProfile.photo}
                name={winProfile.name}
              />
            </div>
          </div>

          {/* All 4 Victorious Photo Tokens */}
          <div className="flex items-center justify-center gap-2 mt-3">
            {[1, 2, 3, 4].map((num) => (
              <div
                key={num}
                className={`w-9 h-9 rounded-full p-0.5 shadow ${
                  isP1 ? 'bg-rose-600' : 'bg-blue-600'
                }`}
              >
                <div className="w-full h-full rounded-full overflow-hidden bg-white">
                  <PlayerAvatarImg
                    player={winner}
                    photo={winProfile.photo}
                    name={winProfile.name}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Clean Tabular Match Breakdown */}
        <div className="grid grid-cols-3 gap-2 py-3.5 px-3 rounded-2xl bg-slate-50 border border-slate-200/80 font-mono tabular-nums">
          <div>
            <div className="text-lg font-bold text-slate-900">{winStats.captures}</div>
            <div className="text-[11px] font-sans text-slate-500">Captures</div>
          </div>
          <div className="border-x border-slate-200/80">
            <div className="text-lg font-bold text-slate-900">{winStats.sixes}</div>
            <div className="text-[11px] font-sans text-slate-500">Sixes Rolled</div>
          </div>
          <div>
            <div className="text-lg font-bold text-slate-900">
              4–{runnerStats.finishedCount}
            </div>
            <div className="text-[11px] font-sans text-slate-500">Home Score</div>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2.5 pt-1">
          <button
            type="button"
            onClick={onPlayAgain}
            className="w-full min-h-[50px] px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-display font-bold text-base flex items-center justify-center gap-2 shadow-md active:scale-[0.99] transition-all whitespace-nowrap touch-manipulation"
          >
            <RotateCcw className="w-4 h-4 shrink-0" />
            <span>Play Again</span>
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            {canEditWinnerPhoto && (
              <button
                type="button"
                onClick={() => onChangeWinnerPhoto(winner)}
                className="min-h-[46px] px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap touch-manipulation"
              >
                <Camera className="w-4 h-4 shrink-0" />
                <span>Change Photo</span>
              </button>
            )}
            <button
              type="button"
              onClick={onOpenRoomMenu}
              className={`${
                canEditWinnerPhoto ? '' : 'col-span-2'
              } min-h-[46px] px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap touch-manipulation`}
            >
              <Users className="w-4 h-4 shrink-0" />
              <span>Online Room</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
