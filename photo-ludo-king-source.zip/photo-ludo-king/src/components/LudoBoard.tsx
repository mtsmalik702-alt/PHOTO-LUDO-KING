import React, { useEffect, useState, useRef, useMemo } from 'react';
import { Star, ArrowUp, ArrowDown, ArrowRight, ArrowLeft, Crown, Camera } from 'lucide-react';
import {
  getTokenBoardCoord,
  YARD_DOCK_COORDS,
} from '../shared/ludoEngine';
import type {
  BoardPoint,
  LudoGameState,
  PlayerId,
} from '../shared/ludoEngine';
import { PlayerAvatarImg } from './PlayerAvatarImg';
import { soundFX } from '../utils/soundEffects';

interface LudoBoardProps {
  gameState: LudoGameState;
  canActForPlayer: (player: PlayerId) => boolean;
  onSelectToken: (tokenId: number) => void;
  onOpenPhotoEditor: (player: PlayerId) => void;
}

const STAR_COORDS = new Set(['8,2', '2,6', '6,12', '12,8']);

function getCellBackground(r: number, c: number): string {
  // Red (Bottom-Left) start & home stretch
  if (r === 13 && c === 6) return 'bg-rose-500 text-white';
  if (c === 7 && r >= 9 && r <= 13) return 'bg-rose-500/90 text-white';

  // Green (Top-Left) start & home stretch
  if (r === 6 && c === 1) return 'bg-emerald-500 text-white';
  if (r === 7 && c >= 1 && c <= 5) return 'bg-emerald-500/90 text-white';

  // Blue (Top-Right) start & home stretch
  if (r === 1 && c === 8) return 'bg-blue-600 text-white';
  if (c === 7 && r >= 1 && r <= 5) return 'bg-blue-600/90 text-white';

  // Amber (Bottom-Right) start & home stretch
  if (r === 8 && c === 13) return 'bg-amber-400 text-slate-900';
  if (r === 7 && c >= 9 && c <= 13) return 'bg-amber-400/90 text-slate-900';

  // Star safe squares
  if (STAR_COORDS.has(`${r},${c}`)) return 'bg-amber-50 text-amber-600';

  return 'bg-white text-slate-400';
}

export const LudoBoard: React.FC<LudoBoardProps> = ({
  gameState,
  canActForPlayer,
  onSelectToken,
  onOpenPhotoEditor,
}) => {
  const [animatingToken, setAnimatingToken] = useState<{
    player: PlayerId;
    tokenId: number;
    coord: BoardPoint;
  } | null>(null);

  const lastAnimatedMoveId = useRef<number>(0);

  // Step-by-step hop animation when a token moves
  useEffect(() => {
    const move = gameState.lastMove;
    if (!move || move.moveId === lastAnimatedMoveId.current) {
      return;
    }
    lastAnimatedMoveId.current = move.moveId;

    const coords = move.pathCoords;
    if (!coords || coords.length <= 1) {
      return;
    }

    let cancelled = false;
    let stepIndex = 1;

    if (move.fromStep === -1) {
      soundFX.playExitYard();
    }

    setAnimatingToken({
      player: move.player,
      tokenId: move.tokenId,
      coord: coords[1],
    });

    const interval = setInterval(() => {
      if (cancelled) return;
      stepIndex += 1;
      if (stepIndex < coords.length) {
        soundFX.playStepHop();
        setAnimatingToken({
          player: move.player,
          tokenId: move.tokenId,
          coord: coords[stepIndex],
        });
      } else {
        clearInterval(interval);
        if (move.capturedToken) {
          soundFX.playCapture();
        } else if (move.reachedHome) {
          soundFX.playReachHome();
        }
        setAnimatingToken(null);
      }
    }, 85);

    return () => {
      cancelled = true;
      clearInterval(interval);
      setAnimatingToken(null);
    };
  }, [gameState.lastMove]);

  // Build render list for all 8 tokens (4 for P1, 4 for P2) with smart collision offsets
  const renderedTokens = useMemo(() => {
    const items: Array<{
      key: string;
      player: PlayerId;
      tokenId: number;
      step: number;
      coord: BoardPoint;
      isMovable: boolean;
      isAnimating: boolean;
    }> = [];

    for (const player of ['P1', 'P2'] as PlayerId[]) {
      const canAct =
        gameState.phase === 'MOVE' &&
        gameState.turn === player &&
        canActForPlayer(player);

      for (const token of gameState.tokens[player]) {
        const isAnim =
          animatingToken?.player === player && animatingToken?.tokenId === token.id;
        const coord = isAnim
          ? animatingToken.coord
          : getTokenBoardCoord(player, token.id, token.step);
        const isMovable = canAct && gameState.movableTokenIds.includes(token.id);

        items.push({
          key: `${player}-${token.id}`,
          player,
          tokenId: token.id,
          step: token.step,
          coord,
          isMovable,
          isAnimating: isAnim,
        });
      }
    }

    // Group tokens on identical track/stretch squares so stacked tokens fan out cleanly
    const groups = new Map<string, typeof items>();
    for (const item of items) {
      if (item.step >= 0 && item.step <= 55 && !item.isAnimating) {
        const k = `${item.coord.row},${item.coord.col}`;
        const list = groups.get(k) || [];
        list.push(item);
        groups.set(k, list);
      }
    }

    return items.map((item) => {
      let offsetRow = 0;
      let offsetCol = 0;
      let stackScale = 1;

      if (item.step >= 0 && item.step <= 55 && !item.isAnimating) {
        const k = `${item.coord.row},${item.coord.col}`;
        const group = groups.get(k);
        if (group && group.length > 1) {
          const idx = group.findIndex((g) => g.key === item.key);
          const count = group.length;
          stackScale = count === 2 ? 0.86 : 0.78;
          const spread = 0.2;
          if (count === 2) {
            offsetCol = idx === 0 ? -spread : spread;
            offsetRow = idx === 0 ? -0.08 : 0.08;
          } else {
            const angle = (idx / count) * Math.PI * 2;
            offsetCol = Math.cos(angle) * spread;
            offsetRow = Math.sin(angle) * spread;
          }
        }
      }

      if (item.step === 56) {
        stackScale = 0.78;
      }

      return {
        ...item,
        displayRow: item.coord.row + offsetRow,
        displayCol: item.coord.col + offsetCol,
        stackScale,
      };
    });
  }, [gameState, animatingToken, canActForPlayer]);

  // Precompute active track cells (excluding the four 6x6 corner yards and 3x3 center)
  const trackCells: Array<{ r: number; c: number }> = [];
  for (let r = 0; r < 15; r++) {
    for (let c = 0; c < 15; c++) {
      const inTopLeft = r < 6 && c < 6;
      const inTopRight = r < 6 && c > 8;
      const inBottomLeft = r > 8 && c < 6;
      const inBottomRight = r > 8 && c > 8;
      const inCenter = r >= 6 && r <= 8 && c >= 6 && c <= 8;
      if (!inTopLeft && !inTopRight && !inBottomLeft && !inBottomRight && !inCenter) {
        trackCells.push({ r, c });
      }
    }
  }

  const p1TurnActive = gameState.turn === 'P1' && gameState.phase !== 'GAME_OVER';
  const p2TurnActive = gameState.turn === 'P2' && gameState.phase !== 'GAME_OVER';

  return (
    <div className="relative w-full aspect-square max-w-[min(94vw,560px)] mx-auto rounded-2xl p-1.5 sm:p-2 bg-slate-900 shadow-xl select-none">
      {/* Inner 15x15 Ludo Grid */}
      <div
        className="relative w-full h-full rounded-xl overflow-hidden bg-slate-300 grid"
        style={{
          gridTemplateColumns: 'repeat(15, minmax(0, 1fr))',
          gridTemplateRows: 'repeat(15, minmax(0, 1fr))',
        }}
      >
        {/* TOP-LEFT YARD: Classic Decorative Emerald Quadrant */}
        <div
          style={{ gridRow: '1 / 7', gridColumn: '1 / 7' }}
          className="bg-emerald-600 p-2 sm:p-3 flex items-center justify-center border-r border-b border-slate-800/20"
        >
          <div className="w-full h-full rounded-xl bg-white/95 p-2.5 flex flex-col items-center justify-center shadow-inner">
            <div className="grid grid-cols-2 gap-2.5 sm:gap-3.5 w-3/4 h-3/4 place-items-center opacity-50">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="w-full aspect-square rounded-full bg-emerald-100 border-2 border-emerald-400/60"
                />
              ))}
            </div>
          </div>
        </div>

        {/* TOP-RIGHT YARD: PLAYER 2 (Royal Blue) Active Photo Yard */}
        <div
          style={{ gridRow: '1 / 7', gridColumn: '10 / 16' }}
          className={`relative bg-blue-600 p-2 sm:p-3 flex items-center justify-center border-l border-b border-slate-800/20 transition-opacity duration-200 ${
            p2TurnActive ? 'ring-2 ring-inset ring-white/90' : ''
          }`}
        >
          <div className="relative w-full h-full rounded-xl bg-white p-2 flex items-center justify-center shadow-inner">
            {/* Player 2 Yard Label & Quick Photo Button */}
            <div className="absolute top-1 left-2 right-1.5 flex items-center justify-between pointer-events-auto z-10">
              <span className="text-[9px] sm:text-[11px] font-display font-bold text-blue-700 truncate max-w-[72%]">
                {gameState.players.P2.name}
              </span>
              {canActForPlayer('P2') && (
                <button
                  type="button"
                  onClick={() => onOpenPhotoEditor('P2')}
                  title="Change Player 2 Photo"
                  className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-blue-50 hover:bg-blue-100 text-blue-700 flex items-center justify-center transition-colors touch-manipulation"
                >
                  <Camera className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* BOTTOM-LEFT YARD: PLAYER 1 (Crimson Red) Active Photo Yard */}
        <div
          style={{ gridRow: '10 / 16', gridColumn: '1 / 7' }}
          className={`relative bg-rose-600 p-2 sm:p-3 flex items-center justify-center border-r border-t border-slate-800/20 transition-opacity duration-200 ${
            p1TurnActive ? 'ring-2 ring-inset ring-white/90' : ''
          }`}
        >
          <div className="relative w-full h-full rounded-xl bg-white p-2 flex items-center justify-center shadow-inner">
            {/* Player 1 Yard Label & Quick Photo Button */}
            <div className="absolute bottom-1 left-2 right-1.5 flex items-center justify-between pointer-events-auto z-10">
              <span className="text-[9px] sm:text-[11px] font-display font-bold text-rose-700 truncate max-w-[72%]">
                {gameState.players.P1.name}
              </span>
              {canActForPlayer('P1') && (
                <button
                  type="button"
                  onClick={() => onOpenPhotoEditor('P1')}
                  title="Change Player 1 Photo"
                  className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-rose-50 hover:bg-rose-100 text-rose-700 flex items-center justify-center transition-colors touch-manipulation"
                >
                  <Camera className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* BOTTOM-RIGHT YARD: Classic Decorative Golden Amber Quadrant */}
        <div
          style={{ gridRow: '10 / 16', gridColumn: '10 / 16' }}
          className="bg-amber-400 p-2 sm:p-3 flex items-center justify-center border-l border-t border-slate-800/20"
        >
          <div className="w-full h-full rounded-xl bg-white/95 p-2.5 flex flex-col items-center justify-center shadow-inner">
            <div className="grid grid-cols-2 gap-2.5 sm:gap-3.5 w-3/4 h-3/4 place-items-center opacity-50">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="w-full aspect-square rounded-full bg-amber-100 border-2 border-amber-400/70"
                />
              ))}
            </div>
          </div>
        </div>

        {/* CENTER 3x3 HOME CROWN */}
        <div
          style={{ gridRow: '7 / 10', gridColumn: '7 / 10' }}
          className="relative overflow-hidden border border-slate-800/25"
        >
          <svg viewBox="0 0 100 100" className="w-full h-full block">
            {/* Top Triangle - Blue (Player 2 Home) */}
            <polygon points="0,0 100,0 50,50" fill="#2563EB" />
            {/* Left Triangle - Emerald */}
            <polygon points="0,0 0,100 50,50" fill="#059669" />
            {/* Right Triangle - Amber */}
            <polygon points="100,0 100,100 50,50" fill="#F59E0B" />
            {/* Bottom Triangle - Red (Player 1 Home) */}
            <polygon points="0,100 100,100 50,50" fill="#E11D48" />
            {/* Crisp Diagonal Dividers */}
            <line x1="0" y1="0" x2="100" y2="100" stroke="#ffffff" strokeWidth="2" />
            <line x1="100" y1="0" x2="0" y2="100" stroke="#ffffff" strokeWidth="2" />
            {/* Center Crown Medallion */}
            <circle cx="50" cy="50" r="16" fill="#0f172a" stroke="#fbbf24" strokeWidth="2.5" />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <Crown className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400" />
          </div>
        </div>

        {/* 72 TRACK & HOME STRETCH CELLS */}
        {trackCells.map(({ r, c }) => {
          const bgClass = getCellBackground(r, c);
          const isStar = STAR_COORDS.has(`${r},${c}`);
          const isRedStart = r === 13 && c === 6;
          const isBlueStart = r === 1 && c === 8;
          const isGreenStart = r === 6 && c === 1;
          const isAmberStart = r === 8 && c === 13;
          const isRedEntryHint = r === 14 && c === 7;
          const isBlueEntryHint = r === 0 && c === 7;

          return (
            <div
              key={`${r}-${c}`}
              style={{ gridRow: r + 1, gridColumn: c + 1 }}
              className={`${bgClass} border-[0.5px] border-slate-300/90 flex items-center justify-center relative`}
            >
              {isStar && (
                <Star className="w-3 h-3 sm:w-4 sm:h-4 fill-amber-400 text-amber-600" />
              )}
              {isRedStart && <ArrowUp className="w-3 h-3 sm:w-4 sm:h-4 stroke-[2.6]" />}
              {isBlueStart && <ArrowDown className="w-3 h-3 sm:w-4 sm:h-4 stroke-[2.6]" />}
              {isGreenStart && <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 stroke-[2.4]" />}
              {isAmberStart && <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 stroke-[2.4]" />}
              {isRedEntryHint && (
                <ArrowUp className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-rose-500 opacity-75" />
              )}
              {isBlueEntryHint && (
                <ArrowDown className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-blue-600 opacity-75" />
              )}
            </div>
          );
        })}

        {/* EXACT DOCK CIRCLES FOR P1 & P2 YARDS (aligned to YARD_DOCK_COORDS) */}
        <div className="absolute inset-0 pointer-events-none">
          {(['P1', 'P2'] as PlayerId[]).map((player) =>
            YARD_DOCK_COORDS[player].map((dock, idx) => {
              const topPct = ((dock.row + 0.5) / 15) * 100;
              const leftPct = ((dock.col + 0.5) / 15) * 100;
              const ringClass =
                player === 'P1'
                  ? 'border-rose-200 bg-rose-50/70'
                  : 'border-blue-200 bg-blue-50/70';

              return (
                <div
                  key={`dock-${player}-${idx}`}
                  style={{
                    top: `${topPct}%`,
                    left: `${leftPct}%`,
                    width: '9.2%',
                    height: '9.2%',
                    transform: 'translate(-50%, -50%)',
                  }}
                  className={`absolute rounded-full border-2 ${ringClass} flex items-center justify-center`}
                >
                  <span className="text-[9px] font-mono font-bold text-slate-400">
                    {idx + 1}
                  </span>
                </div>
              );
            })
          )}
        </div>

        {/* FLOATING PHOTO TOKENS LAYER (All 4 tokens per player show the player's photo!) */}
        <div className="absolute inset-0 pointer-events-none">
          {renderedTokens.map((item) => {
            const topPct = ((item.displayRow + 0.5) / 15) * 100;
            const leftPct = ((item.displayCol + 0.5) / 15) * 100;
            const profile = gameState.players[item.player];
            const isYard = item.step === -1;
            const sizePct = isYard ? 8.8 : 6.9;

            const outerBorderClass =
              item.player === 'P1'
                ? 'bg-rose-600 ring-2 ring-white shadow-md shadow-rose-950/40'
                : 'bg-blue-600 ring-2 ring-white shadow-md shadow-blue-950/40';

            const zIndex = item.isMovable
              ? 40 + item.tokenId
              : item.isAnimating
              ? 50
              : item.player === gameState.turn
              ? 25 + item.tokenId
              : 15 + item.tokenId;

            return (
              <div
                key={item.key}
                style={{
                  top: `${topPct}%`,
                  left: `${leftPct}%`,
                  width: `${sizePct}%`,
                  height: `${sizePct}%`,
                  zIndex,
                  transform: `translate(-50%, -50%) scale(${item.stackScale})`,
                }}
                className="absolute transition-transform duration-150 ease-out"
              >
                {item.isMovable ? (
                  <button
                    type="button"
                    onClick={() => onSelectToken(item.tokenId)}
                    aria-label={`Move ${profile.name} photo token ${item.tokenId + 1}`}
                    className="relative w-full h-full pointer-events-auto touch-manipulation group focus:outline-none"
                  >
                    {/* Expanded 44px+ Android Touch Hitbox */}
                    <span className="absolute -inset-3 rounded-full" />
                    {/* Highlight Selection Ring */}
                    <span
                      className={`absolute -inset-1.5 rounded-full border-2 ${
                        item.player === 'P1'
                          ? 'border-amber-400 bg-rose-500/25'
                          : 'border-amber-400 bg-blue-500/25'
                      }`}
                    />
                    <div
                      className={`w-full h-full rounded-full p-[2.5px] ${outerBorderClass} animate-token-float overflow-hidden`}
                    >
                      <div className="w-full h-full rounded-full overflow-hidden bg-white">
                        <PlayerAvatarImg
                          player={item.player}
                          photo={profile.photo}
                          name={profile.name}
                        />
                      </div>
                    </div>
                    <span
                      className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full text-[8px] sm:text-[9px] font-mono font-bold flex items-center justify-center text-white shadow ${
                        item.player === 'P1' ? 'bg-rose-700' : 'bg-blue-700'
                      }`}
                    >
                      {item.tokenId + 1}
                    </span>
                  </button>
                ) : (
                  <div className="relative w-full h-full">
                    <div
                      className={`w-full h-full rounded-full p-[2px] ${outerBorderClass} overflow-hidden`}
                    >
                      <div className="w-full h-full rounded-full overflow-hidden bg-white">
                        <PlayerAvatarImg
                          player={item.player}
                          photo={profile.photo}
                          name={profile.name}
                        />
                      </div>
                    </div>
                    {item.step === 56 && (
                      <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow">
                        <Crown className="w-2.5 h-2.5" />
                      </span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
