import React from 'react';
import { Dices } from 'lucide-react';
import { getGlobalTrackIndex, SAFE_TRACK_INDICES } from '../shared/ludoEngine';
import type { LudoGameState, PlayerId } from '../shared/ludoEngine';
import { PlayerAvatarImg } from './PlayerAvatarImg';

interface DiceFaceProps {
  value: number | null;
  isRolling: boolean;
  player: PlayerId;
}

const PIP_LAYOUTS: Record<number, number[]> = {
  1: [4],
  2: [0, 8],
  3: [0, 4, 8],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
};

export const DiceFace: React.FC<DiceFaceProps> = ({ value, isRolling, player }) => {
  const displayVal = value ?? 6;
  const pips = PIP_LAYOUTS[displayVal] || PIP_LAYOUTS[6];
  const pipColor =
    displayVal === 1 || displayVal === 6
      ? player === 'P1'
        ? 'bg-rose-600'
        : 'bg-blue-600'
      : 'bg-slate-900';

  return (
    <div
      className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-white border-2 ${
        player === 'P1' ? 'border-rose-200' : 'border-blue-200'
      } shadow-md p-2 grid grid-cols-3 grid-rows-3 place-items-center shrink-0 ${
        isRolling ? 'animate-dice-tumble' : ''
      }`}
    >
      {Array.from({ length: 9 }).map((_, idx) => (
        <span
          key={idx}
          className={`w-2.5 h-2.5 rounded-full transition-opacity duration-100 ${
            pips.includes(idx) ? `${pipColor} opacity-100` : 'opacity-0'
          }`}
        />
      ))}
    </div>
  );
};

interface QuickMoveControlsProps {
  gameState: LudoGameState;
  isRollingAnim: boolean;
  canAct: boolean;
  onRollDice: () => void;
  onSelectToken: (tokenId: number) => void;
}

export const QuickMoveControls: React.FC<QuickMoveControlsProps> = ({
  gameState,
  isRollingAnim,
  canAct,
  onRollDice,
  onSelectToken,
}) => {
  const activePlayer = gameState.turn;
  const profile = gameState.players[activePlayer];
  const isP1 = activePlayer === 'P1';

  const canRoll = canAct && gameState.phase === 'ROLL' && !isRollingAnim;
  const canMove = canAct && gameState.phase === 'MOVE' && gameState.diceValue !== null;

  // Compute helpful action labels for each movable token so Android thumb play is effortless
  const getMoveLabel = (tokenId: number): string => {
    const token = gameState.tokens[activePlayer].find((t) => t.id === tokenId);
    const dice = gameState.diceValue ?? 0;
    if (!token) return `#${tokenId + 1}`;
    if (token.step === -1) return 'Exit Yard';
    const nextStep = token.step + dice;
    if (nextStep === 56) return 'Finish Home!';

    if (nextStep >= 0 && nextStep <= 50) {
      const opp: PlayerId = activePlayer === 'P1' ? 'P2' : 'P1';
      const destIdx = getGlobalTrackIndex(activePlayer, nextStep)!;
      if (!SAFE_TRACK_INDICES.has(destIdx)) {
        const willCapture = gameState.tokens[opp].some(
          (ot) => ot.step >= 0 && ot.step <= 50 && getGlobalTrackIndex(opp, ot.step) === destIdx
        );
        if (willCapture) return 'Capture!';
      } else {
        return 'Safe Star';
      }
    }
    return `+${dice} Steps`;
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-3 sm:p-4 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        {/* Dice Visual + Status */}
        <div className="flex items-center gap-3 min-w-0">
          <DiceFace
            value={gameState.diceValue}
            isRolling={isRollingAnim}
            player={activePlayer}
          />
          <div className="min-w-0">
            <div className="text-xs font-medium text-slate-500 truncate">
              {gameState.phase === 'WAITING_FOR_PLAYERS'
                ? 'Online Room · Waiting'
                : `${profile.name} · ${isP1 ? 'Red' : 'Blue'} Squad`}
            </div>
            <p className="text-sm font-semibold text-slate-900 leading-snug line-clamp-2">
              {gameState.statusMessage}
            </p>
          </div>
        </div>

        {/* Big Thumb-Friendly Roll CTA */}
        <button
          type="button"
          disabled={!canRoll}
          onClick={onRollDice}
          className={`min-h-[52px] px-5 py-3 rounded-xl font-display font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all whitespace-nowrap shrink-0 touch-manipulation ${
            canRoll
              ? isP1
                ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-600/20 active:scale-[0.97]'
                : 'bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-600/20 active:scale-[0.97]'
              : 'bg-slate-100 text-slate-400 cursor-not-allowed'
          }`}
        >
          <Dices className="w-5 h-5 shrink-0" />
          <span>{isRollingAnim ? 'Rolling...' : 'Roll Dice'}</span>
        </button>
      </div>

      {/* Thumb-Zone Quick Photo Token Picker when player has rolled and needs to move */}
      {canMove && gameState.movableTokenIds.length > 0 && (
        <div className="mt-3 pt-3 border-t border-slate-100">
          <p className="text-xs font-medium text-slate-500 mb-2">
            Tap a token on the board or choose below:
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {gameState.movableTokenIds.map((tokenId) => (
              <button
                key={tokenId}
                type="button"
                onClick={() => onSelectToken(tokenId)}
                className={`min-h-[48px] px-2.5 py-1.5 rounded-xl border flex items-center gap-2 text-left transition-all active:scale-[0.97] touch-manipulation ${
                  isP1
                    ? 'border-rose-200 bg-rose-50/70 hover:bg-rose-100/80 text-rose-950'
                    : 'border-blue-200 bg-blue-50/70 hover:bg-blue-100/80 text-blue-950'
                }`}
              >
                <div
                  className={`relative w-8 h-8 rounded-full p-0.5 shrink-0 ${
                    isP1 ? 'bg-rose-600' : 'bg-blue-600'
                  }`}
                >
                  <div className="w-full h-full rounded-full overflow-hidden bg-white">
                    <PlayerAvatarImg
                      player={activePlayer}
                      photo={profile.photo}
                      name={profile.name}
                    />
                  </div>
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] font-mono font-bold leading-tight">
                    Token #{tokenId + 1}
                  </div>
                  <div className="text-xs font-semibold truncate">
                    {getMoveLabel(tokenId)}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
