import React, { useState, useEffect } from 'react';
import { Crown } from 'lucide-react';
import type { PlayerId } from '../shared/ludoEngine';
import defaultRedAvatar from '../assets/images/player_red_avatar_1793641676184.jpg';
import defaultBlueAvatar from '../assets/images/player_blue_avatar_1793641676931.jpg';

interface PlayerAvatarImgProps {
  player: PlayerId;
  photo: string | null;
  name: string;
  className?: string;
}

export const PlayerAvatarImg: React.FC<PlayerAvatarImgProps> = ({
  player,
  photo,
  name,
  className = 'w-full h-full',
}) => {
  const srcToUse = photo || (player === 'P1' ? defaultRedAvatar : defaultBlueAvatar);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [srcToUse]);

  if (hasError || !srcToUse) {
    const bgClass =
      player === 'P1'
        ? 'bg-gradient-to-br from-rose-500 to-red-700 text-white'
        : 'bg-gradient-to-br from-blue-500 to-indigo-700 text-white';
    const initial = (name?.trim()?.[0] || (player === 'P1' ? '1' : '2')).toUpperCase();

    return (
      <div
        className={`${className} ${bgClass} flex flex-col items-center justify-center select-none font-display font-bold`}
      >
        <Crown className="w-1/3 h-1/3 opacity-90 mb-0.5" />
        <span className="text-xs leading-none">{initial}</span>
      </div>
    );
  }

  return (
    <img
      src={srcToUse}
      alt={`${name} token photo`}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      draggable={false}
      className={`${className} object-cover select-none`}
    />
  );
};
