import React, { useState } from 'react';
import { X, Users, Copy, Check, Share2, LogIn, PlusCircle, Wifi, ArrowLeft } from 'lucide-react';
import type { GameMode, LudoGameState, PlayerId } from '../shared/ludoEngine';

interface RoomLobbyModalProps {
  isOpen: boolean;
  mode: GameMode;
  onlineSeat: PlayerId | null;
  wsConnected: boolean;
  roomError: string | null;
  gameState: LudoGameState;
  onCreateRoom: () => void;
  onJoinRoom: (code: string) => void;
  onLeaveOnlineToDemo: () => void;
  onClose: () => void;
}

export const RoomLobbyModal: React.FC<RoomLobbyModalProps> = ({
  isOpen,
  mode,
  onlineSeat,
  wsConnected,
  roomError,
  gameState,
  onCreateRoom,
  onJoinRoom,
  onLeaveOnlineToDemo,
  onClose,
}) => {
  const [joinCode, setJoinCode] = useState('');
  const [copiedType, setCopiedType] = useState<'code' | 'link' | null>(null);

  if (!isOpen) return null;

  const activeRoomCode = mode === 'ONLINE' ? gameState.roomCode : null;

  const copyText = async (text: string, kind: 'code' | 'link') => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedType(kind);
      setTimeout(() => setCopiedType(null), 2000);
    } catch {
      // Fallback copy ignored
    }
  };

  const getShareUrl = () => {
    if (!activeRoomCode || typeof window === 'undefined') return '';
    const url = new URL(window.location.href);
    url.searchParams.set('room', activeRoomCode);
    return url.toString();
  };

  const handleNativeShare = async () => {
    if (!activeRoomCode) return;
    const shareUrl = getShareUrl();
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Photo Ludo King — Play With Me!',
          text: `Join my Photo Ludo King room! Use code: ${activeRoomCode}`,
          url: shareUrl,
        });
        return;
      } catch {
        // User dismissed share sheet
      }
    }
    copyText(shareUrl, 'link');
  };

  const handleJoinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = joinCode.trim().toUpperCase();
    if (cleaned.length >= 4) {
      onJoinRoom(cleaned);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="room-lobby-title"
    >
      <div className="w-full sm:max-w-md bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        <div className="w-10 h-1.5 bg-slate-200 rounded-full mx-auto mt-2.5 sm:hidden" />

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-slate-700" />
            <h2 id="room-lobby-title" className="font-display font-bold text-lg text-slate-900">
              Play Online with Friend
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[44px] min-h-[44px] -mr-2 rounded-full flex items-center justify-center text-slate-500 hover:bg-slate-100 transition-colors touch-manipulation"
            aria-label="Close room menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          {activeRoomCode ? (
            /* Active Online Room View */
            <div className="space-y-4">
              <div className="text-center py-4 px-4 rounded-2xl bg-slate-50 border border-slate-200">
                <p className="text-xs font-medium text-slate-500">
                  Room Code · Share with your friend
                </p>
                <div className="font-mono font-bold text-4xl tracking-[0.22em] text-slate-900 mt-1.5 select-all tabular-nums">
                  {activeRoomCode}
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  You are <span className="font-semibold text-slate-800">{onlineSeat === 'P1' ? 'Player 1 (Red)' : 'Player 2 (Blue)'}</span>
                  {' · '}
                  {gameState.players.P1.connected && gameState.players.P2.connected
                    ? 'Both players connected!'
                    : 'Waiting for friend to join...'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => copyText(activeRoomCode, 'code')}
                  className="min-h-[48px] px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-sm font-semibold text-slate-800 flex items-center justify-center gap-2 transition-colors whitespace-nowrap touch-manipulation"
                >
                  {copiedType === 'code' ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>Copied Code</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleNativeShare}
                  className="min-h-[48px] px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap touch-manipulation"
                >
                  <Share2 className="w-4 h-4" />
                  <span>{copiedType === 'link' ? 'Link Copied!' : 'Invite Friend'}</span>
                </button>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={onLeaveOnlineToDemo}
                  className="min-h-[44px] px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 flex items-center gap-1.5 transition-colors whitespace-nowrap touch-manipulation"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back to 2-Player Local Demo</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-xs font-semibold text-slate-900 transition-colors whitespace-nowrap touch-manipulation"
                >
                  Return to Board
                </button>
              </div>
            </div>
          ) : (
            /* Create or Join Room Options */
            <>
              <div className="space-y-2.5">
                <h3 className="text-sm font-semibold text-slate-900">
                  1. Create a Private Room
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Get a 5-character room code so a friend can join from their own phone with their gallery photo.
                </p>
                <button
                  type="button"
                  onClick={onCreateRoom}
                  className="w-full min-h-[50px] px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold flex items-center justify-center gap-2 shadow-sm active:scale-[0.99] transition-all whitespace-nowrap touch-manipulation"
                >
                  <PlusCircle className="w-4 h-4 shrink-0" />
                  <span>Create Room Code</span>
                </button>
              </div>

              <div className="relative flex items-center py-1">
                <div className="flex-grow border-t border-slate-200" />
                <span className="shrink-0 mx-3 text-xs font-medium text-slate-400">or</span>
                <div className="flex-grow border-t border-slate-200" />
              </div>

              <form onSubmit={handleJoinSubmit} className="space-y-2.5">
                <label
                  htmlFor="join-room-code-input"
                  className="block text-sm font-semibold text-slate-900"
                >
                  2. Join Friend&apos;s Room Code
                </label>
                <div className="flex items-center gap-2">
                  <input
                    id="join-room-code-input"
                    type="text"
                    inputMode="text"
                    autoCapitalize="characters"
                    autoComplete="off"
                    maxLength={5}
                    value={joinCode}
                    onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                    placeholder="E.G. K7P4M"
                    className="flex-1 min-h-[50px] px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 font-mono font-bold text-lg tracking-[0.2em] uppercase text-center text-slate-900 focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-600"
                  />
                  <button
                    type="submit"
                    disabled={joinCode.trim().length < 4}
                    className="min-h-[50px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap shrink-0 touch-manipulation"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Join</span>
                  </button>
                </div>
              </form>

              {roomError && (
                <p className="text-xs font-medium text-rose-600">{roomError}</p>
              )}

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span className="flex items-center gap-1.5">
                  <Wifi className="w-3.5 h-3.5 text-slate-400" />
                  {wsConnected ? 'Multiplayer server ready · Free' : 'Ready to connect on create/join'}
                </span>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
