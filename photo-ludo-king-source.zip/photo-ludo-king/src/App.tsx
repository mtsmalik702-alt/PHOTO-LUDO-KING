import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Camera,
  Users,
  RotateCcw,
  Volume2,
  VolumeX,
  BookOpen,
  Share2,
  Bot,
  Download,
} from 'lucide-react';
import {
  createInitialGameState,
  applyDiceRoll,
  applyTokenMove,
  advanceAfterNoMoves,
  updatePlayerProfile,
  resetMatchKeepProfiles,
  chooseBestMoveTokenId,
} from './shared/ludoEngine';
import type { LudoGameState, PlayerId } from './shared/ludoEngine';
import { LudoBoard } from './components/LudoBoard';
import { PlayerStripCard } from './components/PlayerStripCard';
import { QuickMoveControls } from './components/DiceControl';
import { PhotoEditorModal } from './components/PhotoEditorModal';
import { RoomLobbyModal } from './components/RoomLobbyModal';
import { WinnerModal } from './components/WinnerModal';
import { RulesSheet } from './components/RulesSheet';
import { soundFX } from './utils/soundEffects';

const STORAGE_KEYS = {
  p1Name: 'plk_p1_name',
  p1Photo: 'plk_p1_photo',
  p2Name: 'plk_p2_name',
  p2Photo: 'plk_p2_photo',
  sessionId: 'plk_session_id',
};

function getSafeStorage(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function setSafeStorage(key: string, value: string | null): void {
  try {
    if (value === null) {
      localStorage.removeItem(key);
    } else {
      localStorage.setItem(key, value);
    }
  } catch {
    // Ignore storage quota errors
  }
}

function getOrCreateSessionId(): string {
  try {
    const existing = sessionStorage.getItem(STORAGE_KEYS.sessionId);
    if (existing) return existing;
    const created =
      typeof crypto !== 'undefined' && crypto.randomUUID
        ? crypto.randomUUID()
        : `sess_${Math.random().toString(36).slice(2)}_${Date.now()}`;
    sessionStorage.setItem(STORAGE_KEYS.sessionId, created);
    return created;
  } catch {
    return `sess_${Math.random().toString(36).slice(2)}`;
  }
}

export default function App() {
  const [gameState, setGameState] = useState<LudoGameState>(() =>
    createInitialGameState(
      'LOCAL',
      null,
      {
        name: getSafeStorage(STORAGE_KEYS.p1Name) || 'Player 1',
        photo: getSafeStorage(STORAGE_KEYS.p1Photo),
      },
      {
        name: getSafeStorage(STORAGE_KEYS.p2Name) || 'Player 2',
        photo: getSafeStorage(STORAGE_KEYS.p2Photo),
      }
    )
  );

  // Optional local solo practice bot toggle (OFF by default so 2-player human demo is primary)
  const [localBotEnabled, setLocalBotEnabled] = useState(false);

  // Online Room WebSocket state
  const [onlineSeat, setOnlineSeat] = useState<PlayerId | null>(null);
  const [wsConnected, setWsConnected] = useState(false);
  const [roomError, setRoomError] = useState<string | null>(null);

  // Modals & UI state
  const [photoModalState, setPhotoModalState] = useState<{
    isOpen: boolean;
    player: PlayerId;
  }>({ isOpen: false, player: 'P1' });
  const [isRoomModalOpen, setIsRoomModalOpen] = useState(false);
  const [isRulesOpen, setIsRulesOpen] = useState(false);
  const [isRollingAnim, setIsRollingAnim] = useState(false);
  const [isMuted, setIsMuted] = useState(() => soundFX.isMuted());

  const wsRef = useRef<WebSocket | null>(null);
  const activeOnlineRoomRef = useRef<string | null>(null);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingProfileUpdateRef = useRef<{ name?: string; photo?: string | null } | null>(
    null
  );
  const sessionIdRef = useRef<string>(getOrCreateSessionId());
  const prevRollCountRef = useRef<number>(0);

  // Play dice sound when a new roll arrives from server or local action
  useEffect(() => {
    if (gameState.rollCount > prevRollCountRef.current) {
      prevRollCountRef.current = gameState.rollCount;
      if (gameState.diceValue === 6) {
        soundFX.playSixRolled();
      }
    }
  }, [gameState.rollCount, gameState.diceValue]);

  // Connect & manage WebSocket for Online Room mode
  const connectWebSocket = useCallback(
    (onOpenAction?: (ws: WebSocket) => void) => {
      if (
        wsRef.current &&
        (wsRef.current.readyState === WebSocket.OPEN ||
          wsRef.current.readyState === WebSocket.CONNECTING)
      ) {
        if (wsRef.current.readyState === WebSocket.OPEN && onOpenAction) {
          onOpenAction(wsRef.current);
        } else if (onOpenAction) {
          const existingWs = wsRef.current;
          const handleOpen = () => {
            existingWs.removeEventListener('open', handleOpen);
            onOpenAction(existingWs);
          };
          existingWs.addEventListener('open', handleOpen);
        }
        return;
      }

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setWsConnected(true);
        setRoomError(null);
        if (onOpenAction) {
          onOpenAction(ws);
        } else if (activeOnlineRoomRef.current) {
          // Auto-rejoin room if phone woke up from gallery picker or lock screen
          ws.send(
            JSON.stringify({
              type: 'room:join',
              roomCode: activeOnlineRoomRef.current,
              sessionId: sessionIdRef.current,
              name: getSafeStorage(STORAGE_KEYS.p1Name) || undefined,
              photo: getSafeStorage(STORAGE_KEYS.p1Photo) ?? undefined,
            })
          );
        }

        if (pendingProfileUpdateRef.current) {
          ws.send(
            JSON.stringify({
              type: 'player:updateProfile',
              sessionId: sessionIdRef.current,
              ...pendingProfileUpdateRef.current,
            })
          );
          pendingProfileUpdateRef.current = null;
        }
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'room:state' && data.state) {
            const incomingState = data.state as LudoGameState;
            activeOnlineRoomRef.current = data.roomCode;
            setOnlineSeat(data.seat as PlayerId);
            setGameState(incomingState);
            setRoomError(null);

            // Sync URL query param quietly for easy sharing
            const url = new URL(window.location.href);
            if (url.searchParams.get('room') !== data.roomCode) {
              url.searchParams.set('room', data.roomCode);
              window.history.replaceState({}, '', url.toString());
            }
          } else if (data.type === 'room:error') {
            setRoomError(String(data.message || 'Unable to join room.'));
          }
        } catch {
          // Ignore malformed WS frames
        }
      };

      ws.onclose = () => {
        setWsConnected(false);
        wsRef.current = null;
        // Auto-reconnect if currently inside an online room
        if (activeOnlineRoomRef.current) {
          if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
          reconnectTimerRef.current = setTimeout(() => {
            connectWebSocket();
          }, 1500);
        }
      };
    },
    []
  );

  // Auto-join room if `?room=CODE` is present in the URL on initial load
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const roomParam = params.get('room')?.trim().toUpperCase();
    if (roomParam && roomParam.length >= 4) {
      setIsRoomModalOpen(true);
      connectWebSocket((ws) => {
        ws.send(
          JSON.stringify({
            type: 'room:join',
            roomCode: roomParam,
            sessionId: sessionIdRef.current,
            name: getSafeStorage(STORAGE_KEYS.p1Name) || 'Player 2',
            photo: getSafeStorage(STORAGE_KEYS.p1Photo),
          })
        );
      });
    }

    return () => {
      if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
      if (wsRef.current) {
        activeOnlineRoomRef.current = null;
        wsRef.current.close();
      }
    };
  }, [connectWebSocket]);

  // Local mode: automatically advance turn after brief pause when a roll has no legal moves
  useEffect(() => {
    if (gameState.mode !== 'LOCAL' || gameState.phase !== 'NO_MOVES') {
      return;
    }
    const timer = setTimeout(() => {
      setGameState((prev) => advanceAfterNoMoves(prev));
    }, 1050);
    return () => clearTimeout(timer);
  }, [gameState.mode, gameState.phase]);

  // Optional Local Practice Bot logic when `localBotEnabled` is toggled ON for Player 2
  useEffect(() => {
    if (
      gameState.mode !== 'LOCAL' ||
      !localBotEnabled ||
      gameState.turn !== 'P2' ||
      gameState.phase === 'GAME_OVER' ||
      isRollingAnim
    ) {
      return;
    }

    if (gameState.phase === 'ROLL') {
      const timer = setTimeout(() => {
        setIsRollingAnim(true);
        soundFX.playDiceRoll();
        setTimeout(() => {
          setIsRollingAnim(false);
          setGameState((prev) => applyDiceRoll(prev, 'P2'));
        }, 320);
      }, 650);
      return () => clearTimeout(timer);
    }

    if (gameState.phase === 'MOVE') {
      const timer = setTimeout(() => {
        setGameState((prev) => {
          const chosen = chooseBestMoveTokenId(prev, 'P2');
          if (chosen === null) return prev;
          return applyTokenMove(prev, 'P2', chosen);
        });
      }, 650);
      return () => clearTimeout(timer);
    }
  }, [
    gameState.mode,
    gameState.turn,
    gameState.phase,
    localBotEnabled,
    isRollingAnim,
  ]);

  const canActForPlayer = useCallback(
    (player: PlayerId): boolean => {
      if (gameState.mode === 'LOCAL') {
        if (localBotEnabled && player === 'P2') return false;
        return true;
      }
      return onlineSeat === player;
    },
    [gameState.mode, localBotEnabled, onlineSeat]
  );

  const canEditPlayerPhoto = useCallback(
    (player: PlayerId): boolean => {
      if (gameState.mode === 'LOCAL') return true;
      return onlineSeat === player;
    },
    [gameState.mode, onlineSeat]
  );

  const handleRollDice = () => {
    const activeTurn = gameState.turn;
    if (gameState.phase !== 'ROLL' || !canActForPlayer(activeTurn) || isRollingAnim) {
      return;
    }

    setIsRollingAnim(true);
    soundFX.playDiceRoll();

    if (gameState.mode === 'LOCAL') {
      setTimeout(() => {
        setIsRollingAnim(false);
        setGameState((prev) => applyDiceRoll(prev, activeTurn));
      }, 280);
    } else {
      setTimeout(() => {
        setIsRollingAnim(false);
      }, 280);
      connectWebSocket((ws) => {
        ws.send(
          JSON.stringify({
            type: 'game:roll',
            sessionId: sessionIdRef.current,
          })
        );
      });
    }
  };

  const handleSelectToken = (tokenId: number) => {
    const activeTurn = gameState.turn;
    if (gameState.phase !== 'MOVE' || !canActForPlayer(activeTurn)) {
      return;
    }

    if (gameState.mode === 'LOCAL') {
      setGameState((prev) => applyTokenMove(prev, activeTurn, tokenId));
    } else {
      connectWebSocket((ws) => {
        ws.send(
          JSON.stringify({
            type: 'game:move',
            sessionId: sessionIdRef.current,
            tokenId,
          })
        );
      });
    }
  };

  const handleSaveProfile = (
    player: PlayerId,
    updates: { name?: string; photo?: string | null }
  ) => {
    // Persist locally so player's photo is remembered across refreshes & online rooms
    if (player === 'P1' || gameState.mode === 'ONLINE') {
      if (updates.name !== undefined) setSafeStorage(STORAGE_KEYS.p1Name, updates.name);
      if (updates.photo !== undefined) setSafeStorage(STORAGE_KEYS.p1Photo, updates.photo);
    } else {
      if (updates.name !== undefined) setSafeStorage(STORAGE_KEYS.p2Name, updates.name);
      if (updates.photo !== undefined) setSafeStorage(STORAGE_KEYS.p2Photo, updates.photo);
    }

    if (gameState.mode === 'LOCAL') {
      setGameState((prev) => updatePlayerProfile(prev, player, updates));
    } else {
      // Optimistically update local view immediately and sync over WebSocket
      setGameState((prev) => updatePlayerProfile(prev, player, updates));
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(
          JSON.stringify({
            type: 'player:updateProfile',
            sessionId: sessionIdRef.current,
            ...updates,
          })
        );
      } else {
        pendingProfileUpdateRef.current = updates;
        connectWebSocket();
      }
    }
  };

  const handleCreateOnlineRoom = () => {
    setRoomError(null);
    const savedName = getSafeStorage(STORAGE_KEYS.p1Name) || gameState.players.P1.name;
    const savedPhoto = getSafeStorage(STORAGE_KEYS.p1Photo) ?? gameState.players.P1.photo;

    connectWebSocket((ws) => {
      ws.send(
        JSON.stringify({
          type: 'room:create',
          sessionId: sessionIdRef.current,
          name: savedName,
          photo: savedPhoto,
        })
      );
    });
  };

  const handleJoinOnlineRoom = (code: string) => {
    setRoomError(null);
    const savedName = getSafeStorage(STORAGE_KEYS.p1Name) || 'Player 2';
    const savedPhoto = getSafeStorage(STORAGE_KEYS.p1Photo) ?? gameState.players.P1.photo;

    connectWebSocket((ws) => {
      ws.send(
        JSON.stringify({
          type: 'room:join',
          roomCode: code,
          sessionId: sessionIdRef.current,
          name: savedName === 'Player 1' ? 'Player 2' : savedName,
          photo: savedPhoto,
        })
      );
    });
  };

  const handleSwitchToLocalDemo = () => {
    activeOnlineRoomRef.current = null;
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setOnlineSeat(null);
    setRoomError(null);

    const url = new URL(window.location.href);
    url.searchParams.delete('room');
    window.history.replaceState({}, '', url.toString());

    setGameState(
      createInitialGameState(
        'LOCAL',
        null,
        {
          name: getSafeStorage(STORAGE_KEYS.p1Name) || 'Player 1',
          photo: getSafeStorage(STORAGE_KEYS.p1Photo),
        },
        {
          name: getSafeStorage(STORAGE_KEYS.p2Name) || 'Player 2',
          photo: getSafeStorage(STORAGE_KEYS.p2Photo),
        }
      )
    );
    setIsRoomModalOpen(false);
  };

  const handleResetOrRematch = () => {
    if (gameState.mode === 'LOCAL') {
      setGameState((prev) => resetMatchKeepProfiles(prev));
    } else {
      connectWebSocket((ws) => {
        ws.send(
          JSON.stringify({
            type: 'game:rematch',
            sessionId: sessionIdRef.current,
          })
        );
      });
    }
  };

  const handleToggleMute = () => {
    const nextMuted = soundFX.toggleMute();
    setIsMuted(nextMuted);
  };

  const openPhotoStudio = (player: PlayerId) => {
    const target =
      gameState.mode === 'ONLINE' && onlineSeat ? onlineSeat : player;
    setPhotoModalState({ isOpen: true, player: target });
  };

  const activeTurnCanAct = canActForPlayer(gameState.turn);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* STRICT 3-ZONE TOP BAR CONTRACT */}
      <header className="sticky top-0 z-30 h-14 px-4 lg:px-8 bg-white/95 backdrop-blur-md border-b border-slate-200 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
          }}
          className="font-display font-extrabold text-lg sm:text-xl tracking-tight text-slate-900 whitespace-nowrap shrink-0"
        >
          Photo Ludo King
        </a>

        {/* Zone 2: Clean Single-Line Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            type="button"
            onClick={handleSwitchToLocalDemo}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
              gameState.mode === 'LOCAL' ? 'text-slate-900 underline underline-offset-8 decoration-2' : ''
            }`}
          >
            2-Player Demo
          </button>
          <button
            type="button"
            onClick={() => setIsRoomModalOpen(true)}
            className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
              gameState.mode === 'ONLINE' ? 'text-slate-900 underline underline-offset-8 decoration-2' : ''
            }`}
          >
            Online Room
          </button>
          <button
            type="button"
            onClick={() => openPhotoStudio(onlineSeat || 'P1')}
            className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
          >
            Token Photos
          </button>
          <button
            type="button"
            onClick={() => setIsRulesOpen(true)}
            className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
          >
            Rules
          </button>
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={() => setIsRoomModalOpen(true)}
            className="min-h-[40px] px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 touch-manipulation"
          >
            {gameState.mode === 'ONLINE' && gameState.roomCode
              ? `Room ${gameState.roomCode}`
              : 'Join Friend'}
          </button>
        </div>
      </header>

      {/* MAIN RESPONSIVE TABLETOP WORKSPACE */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3 sm:py-6">
        {/* Compact Mobile & Desktop Action Strip */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3 sm:mb-5">
          {/* Interactive Mode Filter Controls */}
          <div className="flex items-center gap-1 p-1 bg-slate-200/75 rounded-xl">
            <button
              type="button"
              onClick={() => {
                if (gameState.mode === 'ONLINE') handleSwitchToLocalDemo();
                setLocalBotEnabled(false);
              }}
              className={`min-h-[38px] px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 touch-manipulation ${
                gameState.mode === 'LOCAL' && !localBotEnabled
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              2P Pass &amp; Play
            </button>

            <button
              type="button"
              onClick={() => {
                if (gameState.mode === 'ONLINE') handleSwitchToLocalDemo();
                setLocalBotEnabled(true);
              }}
              className={`min-h-[38px] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 touch-manipulation ${
                gameState.mode === 'LOCAL' && localBotEnabled
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Bot className="w-3.5 h-3.5" />
              <span>Practice Bot</span>
            </button>

            <button
              type="button"
              onClick={() => setIsRoomModalOpen(true)}
              className={`min-h-[38px] px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 touch-manipulation ${
                gameState.mode === 'ONLINE'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Online Code</span>
            </button>
          </div>

          {/* Quick Utility Buttons (Upload Photo Anytime, Download ZIP, Sound, Rules, New Match) */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => openPhotoStudio(onlineSeat || gameState.turn)}
              className="min-h-[40px] px-3 py-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-800 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 touch-manipulation"
            >
              <Camera className="w-3.5 h-3.5 text-rose-600 shrink-0" />
              <span>Change Photos</span>
            </button>

            <a
              href="/api/download-source-zip"
              download="photo-ludo-king-source.zip"
              title="Download full Photo Ludo King source code & assets as ZIP"
              className="min-h-[40px] px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors whitespace-nowrap shrink-0 touch-manipulation"
            >
              <Download className="w-3.5 h-3.5 shrink-0" />
              <span>Download ZIP</span>
            </a>

            <button
              type="button"
              onClick={handleToggleMute}
              aria-label={isMuted ? 'Unmute game sounds' : 'Mute game sounds'}
              className="min-w-[40px] min-h-[40px] rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 flex items-center justify-center transition-colors shrink-0 touch-manipulation"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={() => setIsRulesOpen(true)}
              aria-label="Open Ludo rules"
              className="min-w-[40px] min-h-[40px] rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 flex items-center justify-center transition-colors shrink-0 touch-manipulation"
            >
              <BookOpen className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleResetOrRematch}
              title="Restart match (keeps uploaded photos)"
              aria-label="Restart match"
              className="min-w-[40px] min-h-[40px] rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 flex items-center justify-center transition-colors shrink-0 touch-manipulation"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Online Waiting Room Banner when waiting for friend to enter Room Code */}
        {gameState.mode === 'ONLINE' && gameState.phase === 'WAITING_FOR_PLAYERS' && (
          <div className="mb-4 rounded-2xl bg-white border border-blue-200 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-sm">
            <div>
              <div className="text-xs font-medium text-blue-700">
                Online Room Created · Waiting for Friend
              </div>
              <p className="text-sm font-semibold text-slate-900 mt-0.5">
                Ask your friend to enter Room Code{' '}
                <span className="font-mono font-bold text-base tracking-widest text-blue-700 px-1.5">
                  {gameState.roomCode}
                </span>{' '}
                on their phone!
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsRoomModalOpen(true)}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 touch-manipulation"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share Room Code</span>
            </button>
          </div>
        )}

        {/* 12-COLUMN RESPONSIVE GRID: Single-column Android ergonomic stack -> 2-column Desktop Studio */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-8 items-start">
          {/* MOBILE ONLY: Player 2 Strip above the board */}
          <div className="lg:hidden">
            <PlayerStripCard
              player="P2"
              gameState={gameState}
              isMyOnlineSeat={gameState.mode === 'ONLINE' && onlineSeat === 'P2'}
              canEditPhoto={canEditPlayerPhoto('P2')}
              onEditPhoto={openPhotoStudio}
            />
          </div>

          {/* LEFT / CENTER COLUMN: Vibrant Colorful 15x15 Photo Ludo Board */}
          <div className="lg:col-span-7 flex flex-col items-center">
            <LudoBoard
              gameState={gameState}
              canActForPlayer={canActForPlayer}
              onSelectToken={handleSelectToken}
              onOpenPhotoEditor={openPhotoStudio}
            />
          </div>

          {/* RIGHT COLUMN (Desktop) / BOTTOM THUMB ZONE (Android Mobile) */}
          <div className="lg:col-span-5 space-y-3.5 sm:space-y-4">
            {/* Desktop Player 2 Card */}
            <div className="hidden lg:block">
              <PlayerStripCard
                player="P2"
                gameState={gameState}
                isMyOnlineSeat={gameState.mode === 'ONLINE' && onlineSeat === 'P2'}
                canEditPhoto={canEditPlayerPhoto('P2')}
                onEditPhoto={openPhotoStudio}
              />
            </div>

            {/* Active Dice Roller & Quick-Tap Photo Token Controls (Natural Thumb Zone on Mobile!) */}
            <QuickMoveControls
              gameState={gameState}
              isRollingAnim={isRollingAnim}
              canAct={activeTurnCanAct}
              onRollDice={handleRollDice}
              onSelectToken={handleSelectToken}
            />

            {/* Player 1 Strip Card */}
            <PlayerStripCard
              player="P1"
              gameState={gameState}
              isMyOnlineSeat={gameState.mode === 'ONLINE' && onlineSeat === 'P1'}
              canEditPhoto={canEditPlayerPhoto('P1')}
              onEditPhoto={openPhotoStudio}
            />

            {/* Clean Match Activity & Rules Summary */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-4">
              <div className="flex items-center justify-between mb-2.5">
                <h2 className="font-display font-bold text-sm text-slate-900">
                  Recent Moves
                </h2>
                <span className="text-xs text-slate-500 font-mono tabular-nums">
                  Rolls: {gameState.rollCount}
                </span>
              </div>

              {gameState.history.length === 0 ? (
                <p className="text-xs text-slate-500 leading-relaxed">
                  Upload photos from your phone gallery onto your 4 tokens, then roll a 6 to launch onto the track! Star tiles and start arrows are safe zones.
                </p>
              ) : (
                <ul className="divide-y divide-slate-100 max-h-36 overflow-y-auto">
                  {gameState.history.slice(0, 5).map((item) => (
                    <li
                      key={item.id}
                      className="py-1.5 first:pt-0 last:pb-0 flex items-baseline justify-between gap-2 text-xs"
                    >
                      <span className="text-slate-700 truncate">
                        <strong
                          className={
                            item.player === 'P1' ? 'text-rose-700' : 'text-blue-700'
                          }
                        >
                          {gameState.players[item.player].name}:
                        </strong>{' '}
                        {item.text}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Quiet Clean Footer */}
      <footer className="py-4 px-4 text-center text-xs text-slate-500 border-t border-slate-200/60 mt-auto flex flex-wrap items-center justify-center gap-x-2 gap-y-1">
        <span>Photo Ludo King</span>
        <span aria-hidden="true">·</span>
        <span>Free Two-Player Ludo</span>
        <span aria-hidden="true">·</span>
        <a
          href="/api/download-source-zip"
          download="photo-ludo-king-source.zip"
          className="font-semibold text-slate-800 underline underline-offset-4 hover:text-emerald-700 transition-colors whitespace-nowrap"
        >
          Download Project Backup (.zip)
        </a>
      </footer>

      {/* MODALS & MOBILE BOTTOM SHEETS */}
      <PhotoEditorModal
        isOpen={photoModalState.isOpen}
        initialPlayer={photoModalState.player}
        mode={gameState.mode}
        onlineSeat={onlineSeat}
        players={gameState.players}
        onSaveProfile={handleSaveProfile}
        onClose={() => setPhotoModalState((prev) => ({ ...prev, isOpen: false }))}
      />

      <RoomLobbyModal
        isOpen={isRoomModalOpen}
        mode={gameState.mode}
        onlineSeat={onlineSeat}
        wsConnected={wsConnected}
        roomError={roomError}
        gameState={gameState}
        onCreateRoom={handleCreateOnlineRoom}
        onJoinRoom={handleJoinOnlineRoom}
        onLeaveOnlineToDemo={handleSwitchToLocalDemo}
        onClose={() => setIsRoomModalOpen(false)}
      />

      <WinnerModal
        gameState={gameState}
        canEditWinnerPhoto={
          gameState.winner ? canEditPlayerPhoto(gameState.winner) : false
        }
        onPlayAgain={handleResetOrRematch}
        onChangeWinnerPhoto={openPhotoStudio}
        onOpenRoomMenu={() => setIsRoomModalOpen(true)}
      />

      <RulesSheet isOpen={isRulesOpen} onClose={() => setIsRulesOpen(false)} />
    </div>
  );
}

